package com.tl.hz120.system

import android.content.Context
import android.hardware.display.DisplayManager
import android.os.Handler
import android.os.Looper
import android.view.Display
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import java.util.Locale
import kotlin.math.roundToInt

/** Liest echte Display-Modi des Geräts aus. Es werden nur vorhandene Hardware-Modi genutzt. */
class DisplayEngine(ctx: Context) {
    private val dm = ctx.getSystemService(DisplayManager::class.java)

    private fun display(): Display? = dm.getDisplay(Display.DEFAULT_DISPLAY)

    fun currentHz(): Float = display()?.refreshRate ?: 60f

    /** Verfügbare Raten bei der aktuellen Auflösung (gerundet, aufsteigend). */
    fun availableRates(): List<Int> {
        val d = display() ?: return listOf(60)
        val cur = d.mode
        val rates = d.supportedModes
            .filter { it.physicalWidth == cur.physicalWidth && it.physicalHeight == cur.physicalHeight }
            .map { it.refreshRate.roundToInt() }
            .distinct()
            .sorted()
        return rates.ifEmpty { listOf(cur.refreshRate.roundToInt()) }
    }

    fun modeLines(): List<String> {
        val d = display() ?: return emptyList()
        val curId = d.mode.modeId
        return d.supportedModes
            .sortedWith(compareBy({ -it.physicalWidth }, { it.refreshRate }))
            .map {
                val mark = if (it.modeId == curId) "  ← aktiv" else ""
                "Modus ${it.modeId}: ${it.physicalWidth}×${it.physicalHeight} @ " +
                    String.format(Locale.US, "%.2f", it.refreshRate) + " Hz$mark"
            }
    }

    fun hzFlow(): Flow<Float> = callbackFlow {
        val l = object : DisplayManager.DisplayListener {
            override fun onDisplayAdded(displayId: Int) {}
            override fun onDisplayRemoved(displayId: Int) {}
            override fun onDisplayChanged(displayId: Int) {
                if (displayId == Display.DEFAULT_DISPLAY) trySend(currentHz())
            }
        }
        dm.registerDisplayListener(l, Handler(Looper.getMainLooper()))
        trySend(currentHz())
        awaitClose { dm.unregisterDisplayListener(l) }
    }.distinctUntilChanged()
}
