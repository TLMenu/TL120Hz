package com.tl.hz120.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import androidx.core.content.ContextCompat
import com.tl.hz120.R
import com.tl.hz120.TlApp
import com.tl.hz120.data.PerfMode
import com.tl.hz120.data.RateTarget
import com.tl.hz120.data.Verify
import com.tl.hz120.data.AppProfile
import com.tl.hz120.data.resolveTarget
import com.tl.hz120.system.ForegroundDetector
import com.tl.hz120.system.Perms
import com.tl.hz120.ui.MainActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlin.math.roundToInt

/**
 * Hintergrunddienst: erkennt die Vordergrund-App, wählt das passende Profil und wendet es an.
 * Spart Akku, indem er bei ausgeschaltetem Bildschirm pausiert.
 */
class TurboService : Service() {

    companion object {
        private const val CH = "tl_turbo"
        private const val ID = 1
        private const val ACTION_STOP = "com.tl.hz120.STOP"

        fun start(ctx: Context) {
            try {
                ContextCompat.startForegroundService(ctx, Intent(ctx, TurboService::class.java))
            } catch (e: Exception) {
                (ctx.applicationContext as TlApp).log("Dienststart nicht möglich: ${e.javaClass.simpleName}")
            }
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, TurboService::class.java))
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val mutex = Mutex()
    private lateinit var app: TlApp
    private lateinit var detector: ForegroundDetector
    private lateinit var overlay: OverlayController
    private var loopJob: Job? = null

    private var currentPkg: String? = null
    private var lastTarget: RateTarget? = null
    private var hasApplied = false
    private var lastLabel = "System"

    // Schutz vor endlosen Umschaltvorgängen
    private val switches = ArrayDeque<Long>()
    private var pausedUntil = 0L

    private var detectedGames: Set<String> = emptySet()
    private var gamesScanAt = 0L

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            when (i.action) {
                Intent.ACTION_SCREEN_OFF -> {
                    loopJob?.cancel()
                    overlay.hide()
                }
                Intent.ACTION_SCREEN_ON -> startLoop()
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        app = application as TlApp
        detector = ForegroundDetector(this)
        overlay = OverlayController(this) { pkg, mode ->
            val hz = app.engine.availableRates().let { r -> if (90 in r) 90 else r.max() }
            app.store.update {
                it.copy(profiles = it.profiles + (pkg to AppProfile(pkg, mode, hz, true)))
            }
        }

        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "TL120Hz Dienst", NotificationManager.IMPORTANCE_LOW))
        val n = buildNotification("Bereit")
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(ID, n)
        }

        ContextCompat.registerReceiver(
            this, screenReceiver,
            IntentFilter().apply {
                addAction(Intent.ACTION_SCREEN_OFF)
                addAction(Intent.ACTION_SCREEN_ON)
            },
            ContextCompat.RECEIVER_NOT_EXPORTED
        )

        app.runtime.update { it.copy(serviceRunning = true) }
        app.log("Dienst gestartet")

        scope.launch { app.store.settings.collect { evaluate() } }
        scope.launch {
            app.engine.hzFlow().collect { hz ->
                overlay.updateHz(hz)
                postNotif(lastLabel, hz)
            }
        }
        startLoop()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            app.store.update { it.copy(serviceEnabled = false) }
            stopSelf()
            return START_NOT_STICKY
        }
        scope.launch { evaluate() }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        try {
            unregisterReceiver(screenReceiver)
        } catch (_: Exception) {
        }
        overlay.hide()
        scope.cancel()
        // Ohne aktiven globalen Modus werden die ursprünglichen Systemwerte wiederhergestellt.
        if (!app.store.settings.value.global.enabled) {
            runBlocking { app.controller.restore() }
        }
        app.runtime.update { it.copy(serviceRunning = false, foreground = null, applied = "System") }
        app.log("Dienst beendet")
        super.onDestroy()
    }

    private fun startLoop() {
        loopJob?.cancel()
        loopJob = scope.launch {
            detector.reset()
            var first = true
            while (isActive) {
                if (Perms.usage(this@TurboService)) {
                    val raw = detector.poll()
                    val eff = if (detector.isNeutral(raw)) null else raw
                    if (eff != currentPkg || first) {
                        currentPkg = eff
                        app.runtime.update { it.copy(foreground = eff) }
                        evaluate()
                    }
                } else if (first) {
                    app.log("Nutzungszugriff fehlt – nur globaler Modus aktiv")
                    evaluate()
                }
                first = false
                delay(app.store.settings.value.intervalMs)
            }
        }
    }

    private fun gameSet(): Set<String> {
        val s = app.store.settings.value
        val now = SystemClock.elapsedRealtime()
        if (now - gamesScanAt > 5 * 60_000L) {
            gamesScanAt = now
            detectedGames = app.scanner.scan().filter { it.isGame }.map { it.pkg }.toSet()
        }
        return (detectedGames + s.manualGames) - s.hiddenGames
    }

    private suspend fun evaluate() = mutex.withLock {
        val s = app.store.settings.value
        val pkg = currentPkg
        val rates = app.engine.availableRates()
        val games = gameSet()
        val prof = pkg?.let { s.profiles[it] }

        val (target, label) = decide(s, pkg, prof, games, rates)

        val showOverlay = pkg != null && pkg in games && s.overlayEnabled && Perms.overlay(this)
        if (showOverlay) overlay.show(pkg!!, prof?.mode ?: PerfMode.ULTRA) else overlay.hide()

        if (hasApplied && target == lastTarget) {
            lastLabel = label
            app.runtime.update { it.copy(applied = label) }
            postNotif(label, app.engine.currentHz())
            return@withLock
        }

        val now = SystemClock.elapsedRealtime()
        if (now < pausedUntil) return@withLock
        while (switches.isNotEmpty() && now - switches.first() > 12_000) switches.removeFirst()
        if (switches.size >= 6) {
            pausedUntil = now + 30_000
            app.log("Schutz: zu viele Wechsel – Automatik 30 s pausiert")
            return@withLock
        }
        switches.addLast(now)

        if (target == null) {
            app.controller.restore()
            app.runtime.update { it.copy(applied = label, route = "") }
        } else {
            val r = app.controller.apply(target)
            app.runtime.update {
                val lim = if (pkg != null && target.locked && r.verify == Verify.NOT_CONFIRMED)
                    it.limited + (pkg to r.observed.roundToInt())
                else if (pkg != null) it.limited - pkg else it.limited
                it.copy(
                    applied = label, verify = r.verify, route = r.route,
                    observedHz = r.observed.roundToInt(), limited = lim
                )
            }
            app.log("$label → ${r.verify.name.lowercase()} (${r.observed.roundToInt()} Hz)")
        }
        lastTarget = target
        hasApplied = true
        lastLabel = label
        postNotif(label, app.engine.currentHz())
    }

    private fun decide(
        s: com.tl.hz120.data.TlSettings, pkg: String?, prof: AppProfile?,
        games: Set<String>, rates: List<Int>
    ): Pair<RateTarget?, String> = when {
        pkg != null && pkg in s.blacklist -> null to "Ausgeschlossen"
        prof != null && prof.enabled -> resolveTarget(prof.mode, prof.hz, rates) to "Profil: ${prof.mode.label}"
        pkg != null && pkg in games && s.gameAuto -> resolveTarget(PerfMode.ULTRA, 0, rates) to "Game Turbo: Ultra"
        s.global.enabled -> resolveTarget(s.global.mode, s.global.hz, rates) to "Global: ${s.global.mode.label}"
        else -> null to "System"
    }

    private fun buildNotification(text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, TurboService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("TL120Hz")
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(
                android.graphics.drawable.Icon.createWithResource(this, R.drawable.ic_stat), "Stopp", stop
            ).build())
            .build()
    }

    private fun postNotif(label: String, hz: Float) {
        try {
            getSystemService(NotificationManager::class.java)
                .notify(ID, buildNotification("$label · ${hz.roundToInt()} Hz"))
        } catch (_: Exception) {
        }
    }
}
