package com.tl.hz120.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.tl.hz120.TlApp
import com.tl.hz120.data.AppInfo
import com.tl.hz120.data.AppProfile
import com.tl.hz120.data.HardwareProfile
import com.tl.hz120.system.CompatEntry
import com.tl.hz120.data.PerfMode
import com.tl.hz120.service.TurboService
import com.tl.hz120.system.LiveMonitor
import com.tl.hz120.system.LiveSnapshot
import com.tl.hz120.system.Perms
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

data class PermState(
    val writeSettings: Boolean,
    val secure: Boolean,
    val usage: Boolean,
    val overlay: Boolean,
    val notif: Boolean
)

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val a = app as TlApp

    val settings = a.store.settings
    val runtime = a.runtime
    val rates = a.engine.availableRates()
    val maxHz = rates.max()
    val modeLines = a.engine.modeLines()
    val vendorKeys = a.controller.presentVendorKeys()

    val hz: StateFlow<Int> = a.engine.hzFlow().map { it.roundToInt() }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), a.engine.currentHz().roundToInt())

    private val _perms = MutableStateFlow(readPerms())
    val perms: StateFlow<PermState> = _perms

    private val _apps = MutableStateFlow<List<AppInfo>>(emptyList())
    val apps: StateFlow<List<AppInfo>> = _apps

    val games: StateFlow<List<AppInfo>> = combine(_apps, settings) { list, s ->
        list.filter { (it.isGame || it.pkg in s.manualGames) && it.pkg !in s.hiddenGames }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val rootState = MutableStateFlow<Boolean?>(null)

    /** Live-Werte laufen nur, solange ein Screen sie beobachtet (WhileSubscribed). */
    val live: StateFlow<LiveSnapshot?> = LiveMonitor(app, a.engine).flow()
        .map<LiveSnapshot, LiveSnapshot?> { it }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    private val _hardware = MutableStateFlow<HardwareProfile?>(null)
    val hardware: StateFlow<HardwareProfile?> = _hardware

    private val _compat = MutableStateFlow<CompatEntry?>(null)
    val compat: StateFlow<CompatEntry?> = _compat

    fun rescanHardware() {
        viewModelScope.launch(Dispatchers.IO) {
            val h = a.smart.analyze()
            _hardware.value = h
            _compat.value = a.compat.match(h)
        }
    }

    init {
        loadApps()
        // Nach App-Start laufenden Dienst wieder anstoßen, falls gewünscht.
        if (settings.value.serviceEnabled) TurboService.start(a)
        rescanHardware()
    }

    private fun readPerms() = PermState(
        a.controller.canWriteSystem(), a.controller.canWriteSecure(),
        Perms.usage(a), Perms.overlay(a), Perms.notif(a)
    )

    fun refreshPerms() {
        _perms.value = readPerms()
    }

    fun loadApps() {
        viewModelScope.launch {
            _apps.value = withContext(Dispatchers.IO) { a.scanner.scan() }
        }
    }

    private fun defaultHz() = if (90 in rates) 90 else maxHz

    private fun ensureService() {
        a.store.update { it.copy(serviceEnabled = true) }
        // Läuft der Dienst bereits, reicht die Store-Änderung: der Dienst wertet sie selbst aus.
        if (!a.runtime.value.serviceRunning) TurboService.start(a)
    }

    // --- Global ---------------------------------------------------------------------------
    fun setUltra(on: Boolean) {
        a.store.update {
            it.copy(global = it.global.copy(enabled = on, mode = if (on) PerfMode.ULTRA else it.global.mode, hz = 0))
        }
        ensureService()
    }

    fun setGlobalHz(h: Int) {
        a.store.update {
            it.copy(global = it.global.copy(enabled = true, mode = if (h == maxHz) PerfMode.ULTRA else PerfMode.PERFORMANCE, hz = h))
        }
        ensureService()
    }

    fun setGlobalBalanced() {
        a.store.update { it.copy(global = it.global.copy(enabled = true, mode = PerfMode.BALANCED, hz = 0)) }
        ensureService()
    }

    fun resetGlobal() {
        a.store.update { it.copy(global = it.global.copy(enabled = false)) }
        ensureService()
    }

    // --- Profile --------------------------------------------------------------------------
    fun setProfile(pkg: String, f: (AppProfile) -> AppProfile) {
        a.store.update {
            val cur = it.profiles[pkg] ?: AppProfile(pkg, PerfMode.PERFORMANCE, defaultHz(), true)
            it.copy(profiles = it.profiles + (pkg to f(cur)))
        }
        ensureService()
    }

    fun setMode(pkg: String, mode: PerfMode) = setProfile(pkg) {
        it.copy(mode = mode, hz = if (it.hz in rates) it.hz else defaultHz())
    }

    fun setProfileHz(pkg: String, h: Int) = setProfile(pkg) { it.copy(hz = h) }

    fun removeProfile(pkg: String) {
        a.store.update { it.copy(profiles = it.profiles - pkg) }
    }

    fun toggleBlacklist(pkg: String) {
        a.store.update { it.copy(blacklist = if (pkg in it.blacklist) it.blacklist - pkg else it.blacklist + pkg) }
        ensureService()
    }

    // --- Spiele ---------------------------------------------------------------------------
    fun addGame(pkg: String) {
        a.store.update { it.copy(manualGames = it.manualGames + pkg, hiddenGames = it.hiddenGames - pkg) }
    }

    fun removeGame(pkg: String) {
        a.store.update { it.copy(manualGames = it.manualGames - pkg, hiddenGames = it.hiddenGames + pkg) }
    }

    // --- Einstellungen --------------------------------------------------------------------
    fun setGameAuto(on: Boolean) = a.store.update { it.copy(gameAuto = on) }
    fun setOverlay(on: Boolean) = a.store.update { it.copy(overlayEnabled = on) }
    fun setAutoStart(on: Boolean) = a.store.update { it.copy(autoStart = on) }
    fun setRoot(on: Boolean) = a.store.update { it.copy(useRoot = on) }

    fun setService(on: Boolean) {
        a.store.update { it.copy(serviceEnabled = on) }
        if (on) TurboService.start(a) else TurboService.stop(a)
    }

    fun checkRoot() {
        viewModelScope.launch(Dispatchers.IO) { rootState.value = a.controller.rootAvailable() }
    }
}
