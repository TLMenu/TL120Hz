package com.tl.hz120.ui

import androidx.compose.material3.CircularProgressIndicator

import androidx.compose.material3.OutlinedTextFieldDefaults

import androidx.compose.material3.OutlinedTextField

import androidx.compose.material3.TextButton

import androidx.compose.material3.SwitchDefaults

import androidx.compose.material3.Switch

import androidx.compose.material3.AlertDialog

import android.content.Context
import android.util.LruCache
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun TlCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val shape = TlRadius.card
    var m = modifier.fillMaxWidth().clip(shape).background(Surface1).border(TlStroke.hairline, Line, shape)
    if (onClick != null) m = m.clickable(onClick = onClick)
    Column(m.padding(TlSpace.sm + TlSpace.xxs), content = content)
}

@Composable
fun Pill(text: String, selected: Boolean, enabled: Boolean = true, onClick: () -> Unit) {
    val bg by animateColorAsState(if (selected) Brand else Surface2, tween(TlMotion.fast), label = "pill")
    Box(
        Modifier
            .clip(TlRadius.pill)
            .background(bg)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = TlSpace.md, vertical = TlSpace.chip)
            .alpha(if (enabled) 1f else TlAlpha.disabled),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = if (selected) Color.Black else TextC, style = TlType.label)
    }
}

@Composable
fun Caps(text: String) {
    Text(text.uppercase(), style = TlType.overline, color = Muted)
}

@Composable
fun Stat(label: String, value: String, modifier: Modifier = Modifier) {
    TlCard(modifier) {
        Caps(label)
        Spacer(Modifier.height(TlSpace.xs))
        Text(value, style = TlType.stat, color = TextC, maxLines = 1)
    }
}

enum class Level { OK, WARN, BAD }

@Composable
fun StatusRow(title: String, detail: String, level: Level) {
    val c = when (level) { Level.OK -> Good; Level.WARN -> Warn; Level.BAD -> Bad }
    Row(Modifier.fillMaxWidth().padding(vertical = TlSpace.xs), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(TlSize.dot).clip(CircleShape).background(c))
        Spacer(Modifier.width(TlSpace.sm))
        Column(Modifier.weight(1f)) {
            Text(title, color = TextC, style = TlType.body)
            Text(detail, color = Muted, style = TlType.caption)
        }
    }
}

@Composable
fun HzRing(hz: Int, max: Int, on: Boolean, onClick: () -> Unit) {
    val prog by animateFloatAsState(
        if (on) (hz / max.coerceAtLeast(1).toFloat()).coerceIn(0f, 1f) else 0f, tween(TlMotion.ring), label = "ring"
    )
    Box(Modifier.size(TlSize.ring).clip(CircleShape).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize().padding(10.dp)) {
            val st = Stroke(width = 18.dp.toPx(), cap = StrokeCap.Round)
            drawArc(Line, 135f, 270f, false, style = st)
            drawArc(Brand, 135f, 270f * prog, false, style = st)
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("$hz", style = TlType.display, color = TextC)
            Text("Hz", style = TlType.title, color = Muted)
            Spacer(Modifier.height(TlSpace.xs))
            Text(
                if (on) "ULTRA REFRESH AN" else "ULTRA REFRESH AUS",
                style = TlType.overline, color = if (on) Brand else Muted
            )
        }
    }
}

object IconCache {
    private val cache = LruCache<String, ImageBitmap>(200)
    fun get(ctx: Context, pkg: String): ImageBitmap? {
        cache.get(pkg)?.let { return it }
        return try {
            ctx.packageManager.getApplicationIcon(pkg).toBitmap(96, 96).asImageBitmap().also { cache.put(pkg, it) }
        } catch (_: Exception) {
            null
        }
    }
}

@Composable
fun AppIcon(pkg: String, size: Dp = TlSize.appIcon) {
    val ctx = LocalContext.current
    val bmp by produceState<ImageBitmap?>(null, pkg) {
        value = withContext(Dispatchers.IO) { IconCache.get(ctx, pkg) }
    }
    val b = bmp
    if (b != null) {
        Image(b, null, Modifier.size(size).clip(TlRadius.icon))
    } else {
        Box(Modifier.size(size).clip(TlRadius.icon).background(Surface2))
    }
}

@Composable
fun ScreenList(title: String, subtitle: String?, pad: PaddingValues, content: LazyListScope.() -> Unit) {
    val top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    LazyColumn(
        Modifier.fillMaxSize().background(Bg),
        contentPadding = PaddingValues(
            start = 20.dp, end = 20.dp,
            top = top + TlSpace.md, bottom = pad.calculateBottomPadding() + TlSpace.xl
        ),
        verticalArrangement = Arrangement.spacedBy(TlSpace.xs + TlSpace.xxs)
    ) {
        item {
            Column {
                Text(title, style = TlType.headline, color = TextC)
                if (subtitle != null) Text(subtitle, style = TlType.bodySmall, color = Muted)
            }
        }
        content()
    }
}

/** Farbton einer Textaktion. Primary = Akzent, Secondary = gedämpft, Danger = Fehlerfarbe. */
enum class ActionTone { Primary, Secondary, Danger }

@Composable
fun TlTextAction(text: String, tone: ActionTone = ActionTone.Primary, onClick: () -> Unit) {
    val c = when (tone) {
        ActionTone.Primary -> Brand
        ActionTone.Secondary -> Muted
        ActionTone.Danger -> Bad
    }
    TextButton(onClick = onClick) { Text(text, style = TlType.label, color = c) }
}

@Composable
fun TlSwitchRow(title: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = TlSpace.xxs), verticalAlignment = Alignment.CenterVertically) {
        Text(title, Modifier.weight(1f), style = TlType.body, color = TextC)
        Switch(
            checked, onChange,
            colors = SwitchDefaults.colors(checkedTrackColor = Brand, checkedThumbColor = Color(0xFF000000))
        )
    }
}

/** Einheitlicher Dialog: Oberflächenfarbe, Kartenradius und Schließen-Aktion. */
@Composable
fun TlDialog(title: String, onDismiss: () -> Unit, text: @Composable () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Surface1,
        shape = TlRadius.card,
        confirmButton = { TlTextAction("Schließen", ActionTone.Secondary, onDismiss) },
        title = { Text(title, style = TlType.title, color = TextC) },
        text = text
    )
}

/** Beschriftete Wertzeile, z. B. für Hardware- und Messwerte. */
@Composable
fun InfoRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = TlSpace.xxs)) {
        Text(label, color = Muted, style = TlType.caption, modifier = Modifier.weight(0.4f))
        Text(value, style = TlType.caption, color = TextC, modifier = Modifier.weight(0.6f))
    }
}

/** Abschnittsüberschrift zur Gliederung langer Screens, z. B. "Diagnose". */
@Composable
fun SectionHeader(text: String) {
    Text(text.uppercase(), style = TlType.overline, color = Muted, modifier = Modifier.padding(top = TlSpace.sm))
}

/** Einheitliches Suchfeld: gleiche Farben und Form wie die Karten. */
@Composable
fun TlSearchField(value: String, onValueChange: (String) -> Unit, placeholder: String, modifier: Modifier = Modifier) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        modifier = modifier,
        singleLine = true,
        textStyle = TlType.body.copy(color = TextC),
        placeholder = { Text(placeholder, style = TlType.body, color = Muted) },
        shape = TlRadius.icon,
        colors = OutlinedTextFieldDefaults.colors(
            focusedContainerColor = Surface1,
            unfocusedContainerColor = Surface1,
            focusedBorderColor = Brand,
            unfocusedBorderColor = Line,
            cursorColor = Brand,
            focusedTextColor = TextC,
            unfocusedTextColor = TextC
        )
    )
}

/** Leerer Zustand mit Titel und Erklärung statt eines nackten Satzes. */
@Composable
fun EmptyState(title: String, detail: String) {
    Column(Modifier.fillMaxWidth().padding(vertical = TlSpace.lg), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(title, style = TlType.title, color = TextC)
        Spacer(Modifier.height(TlSpace.xxs))
        Text(detail, style = TlType.caption, color = Muted)
    }
}

/** Ladezustand für Messungen und Analysen. */
@Composable
fun LoadingHint(text: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        CircularProgressIndicator(Modifier.size(14.dp), color = Brand, strokeWidth = 2.dp)
        Spacer(Modifier.width(TlSpace.xs))
        Text(text, style = TlType.caption, color = Muted)
    }
}
