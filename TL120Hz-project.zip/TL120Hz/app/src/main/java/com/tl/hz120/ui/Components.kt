package com.tl.hz120.ui

import android.content.Context
import android.util.LruCache
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun TlCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val shape = RoundedCornerShape(20.dp)
    var m = modifier.fillMaxWidth().clip(shape).background(Surface1).border(1.dp, Line, shape)
    if (onClick != null) m = m.clickable(onClick = onClick)
    Column(m.padding(16.dp), content = content)
}

@Composable
fun Pill(text: String, selected: Boolean, enabled: Boolean = true, onClick: () -> Unit) {
    val bg by animateColorAsState(if (selected) Accent else Surface2, label = "pill")
    Box(
        Modifier
            .clip(RoundedCornerShape(50))
            .background(bg)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 10.dp)
            .alpha(if (enabled) 1f else 0.35f),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = if (selected) Color.Black else TextC, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
    }
}

@Composable
fun Label(text: String) {
    Text(text.uppercase(), fontSize = 11.sp, letterSpacing = 1.3.sp, color = Muted, fontWeight = FontWeight.Medium)
}

@Composable
fun Stat(label: String, value: String, modifier: Modifier = Modifier) {
    TlCard(modifier) {
        Label(label)
        Spacer(Modifier.height(6.dp))
        Text(value, fontSize = 22.sp, color = TextC, fontWeight = FontWeight.Medium, maxLines = 1)
    }
}

enum class Level { OK, WARN, BAD }

@Composable
fun StatusRow(title: String, detail: String, level: Level) {
    val c = when (level) { Level.OK -> Good; Level.WARN -> Warn; Level.BAD -> Bad }
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(10.dp).clip(CircleShape).background(c))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = TextC, fontSize = 15.sp)
            Text(detail, color = Muted, fontSize = 12.sp)
        }
    }
}

@Composable
fun HzRing(hz: Int, max: Int, on: Boolean, onClick: () -> Unit) {
    val prog by animateFloatAsState(
        if (on) (hz / max.coerceAtLeast(1).toFloat()).coerceIn(0f, 1f) else 0f, tween(600), label = "ring"
    )
    Box(Modifier.size(240.dp).clip(CircleShape).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize().padding(10.dp)) {
            val st = Stroke(width = 18.dp.toPx(), cap = StrokeCap.Round)
            drawArc(Line, 135f, 270f, false, style = st)
            drawArc(Accent, 135f, 270f * prog, false, style = st)
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("$hz", fontSize = 72.sp, fontWeight = FontWeight.Light, color = TextC)
            Text("Hz", fontSize = 16.sp, color = Muted)
            Spacer(Modifier.height(8.dp))
            Text(
                if (on) "ULTRA REFRESH AN" else "ULTRA REFRESH AUS",
                fontSize = 11.sp, letterSpacing = 1.5.sp, color = if (on) Accent else Muted
            )
        }
    }
}

object IconCache {
    private val cache = LruCache<String, ImageBitmap>(200)
    fun get(ctx: Context, pkg: String): ImageBitmap? {
        cache.get(pkg)?.let { return it }
        return try {
            ctx.packageManager.getApplicationIcon(pkg).toBitmap(96, 96).asImageBitmap().also { cache.put(pkg, it) }
        } catch (_: Exception) {
            null
        }
    }
}

@Composable
fun AppIcon(pkg: String, size: Dp = 44.dp) {
    val ctx = LocalContext.current
    val bmp by produceState<ImageBitmap?>(null, pkg) {
        value = withContext(Dispatchers.IO) { IconCache.get(ctx, pkg) }
    }
    val b = bmp
    if (b != null) {
        Image(b, null, Modifier.size(size).clip(RoundedCornerShape(10.dp)))
    } else {
        Box(Modifier.size(size).clip(RoundedCornerShape(10.dp)).background(Surface2))
    }
}

@Composable
fun ScreenList(title: String, subtitle: String?, pad: PaddingValues, content: LazyListScope.() -> Unit) {
    val top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    LazyColumn(
        Modifier.fillMaxSize().background(Bg),
        contentPadding = PaddingValues(
            start = 20.dp, end = 20.dp,
            top = top + 20.dp, bottom = pad.calculateBottomPadding() + 24.dp
        ),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Column {
                Text(title, fontSize = 30.sp, fontWeight = FontWeight.SemiBold, color = TextC, letterSpacing = (-0.5).sp)
                if (subtitle != null) Text(subtitle, color = Muted, fontSize = 14.sp)
            }
        }
        content()
    }
}
