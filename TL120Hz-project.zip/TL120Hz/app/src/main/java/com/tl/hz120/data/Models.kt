package com.tl.hz120.data

import kotlin.math.roundToInt

enum class PerfMode(val label: String, val blurb: String) {
    BALANCED("Balanced", "System entscheidet adaptiv zwischen niedrigster und höchster Rate"),
    PERFORMANCE("Performance", "Feste Rate laut Profil"),
    ULTRA("Ultra Refresh", "Höchste verfügbare Rate, fest")
}

data class GlobalState(
    val enabled: Boolean = false,
    val mode: PerfMode = PerfMode.ULTRA,
    val hz: Int = 0
)

data class AppProfile(
    val pkg: String,
    val mode: PerfMode,
    val hz: Int = 0,
    val enabled: Boolean = true
)

data class TlSettings(
    val global: GlobalState = GlobalState(),
    val profiles: Map<String, AppProfile> = emptyMap(),
    val blacklist: Set<String> = emptySet(),
    val manualGames: Set<String> = emptySet(),
    val hiddenGames: Set<String> = emptySet(),
    val gameAuto: Boolean = true,
    val overlayEnabled: Boolean = true,
    val serviceEnabled: Boolean = false,
    val autoStart: Boolean = true,
    val useRoot: Boolean = false,
    val intervalMs: Long = 1500
)

/** Gewünschtes Min/Peak-Fenster der Bildwiederholrate in Hz. */
data class RateTarget(val min: Float, val peak: Float) {
    val locked get() = min == peak
}

fun resolveTarget(mode: PerfMode, hz: Int, rates: List<Int>): RateTarget {
    val max = rates.max().toFloat()
    val low = rates.min().toFloat()
    return when (mode) {
        PerfMode.ULTRA -> RateTarget(max, max)
        PerfMode.PERFORMANCE -> {
            val h = if (hz in rates) hz.toFloat() else max
            RateTarget(h, h)
        }
        PerfMode.BALANCED -> RateTarget(low, max)
    }
}

enum class Verify { UNKNOWN, CONFIRMED, NOT_CONFIRMED, NO_ROUTE }

data class AppInfo(val pkg: String, val label: String, val isGame: Boolean)

/** Laufzeitzustand (nicht persistent). */
data class RtState(
    val serviceRunning: Boolean = false,
    val foreground: String? = null,
    val applied: String = "System",
    val verify: Verify = Verify.UNKNOWN,
    val observedHz: Int = 0,
    val route: String = "",
    val limited: Map<String, Int> = emptyMap(),
    val log: List<String> = emptyList()
)

fun Float.hzInt() = roundToInt()
