package com.tl.hz120.ui

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tl.hz120.data.PerfMode
import com.tl.hz120.data.Verify
import com.tl.hz120.system.Perms

private fun verifyText(v: Verify, observed: Int): Pair<String, Level> = when (v) {
    Verify.CONFIRMED -> "Bestätigt: Das Display läuft mit der angeforderten Rate ($observed Hz)." to Level.OK
    Verify.NOT_CONFIRMED -> "Nicht bestätigt: System oder Hersteller ignoriert die Anfrage (gemessen: $observed Hz)." to Level.BAD
    Verify.NO_ROUTE -> "Keine Schreib-Berechtigung – siehe Einstellungen." to Level.BAD
    Verify.UNKNOWN -> "Noch nicht getestet." to Level.WARN
}

// ======================================================================================
// HOME
// ======================================================================================
@Composable
fun HomeScreen(vm: MainViewModel, pad: PaddingValues) {
    val s by vm.settings.collectAsStateWithLifecycle()
    val rt by vm.runtime.collectAsStateWithLifecycle()
    val hz by vm.hz.collectAsStateWithLifecycle()
    val p by vm.perms.collectAsStateWithLifecycle()
    val games by vm.games.collectAsStateWithLifecycle()
    val (vText, vLevel) = verifyText(rt.verify, rt.observedHz)
    val canControl = p.writeSettings || p.secure || s.useRoot

    ScreenList("TL 120Hz", "Bildwiederholrate, Profile, Game Turbo", pad) {
        item {
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                HzRing(hz, vm.maxHz, s.global.enabled) { vm.setUltra(!s.global.enabled) }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                Stat("Aktuell", "$hz Hz", Modifier.weight(1f))
                Stat("Maximal", "${vm.maxHz} Hz", Modifier.weight(1f))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                Stat("Modus", rt.applied, Modifier.weight(1f))
                Stat("Spiele", "${games.size}", Modifier.weight(1f))
            }
        }
        item { Stat("Aktive App-Profile", "${s.profiles.values.count { it.enabled }}") }
        item {
            TlCard {
                Caps("Kompatibilität auf diesem Gerät")
                Spacer(Modifier.height(8.dp))
                StatusRow(
                    "Display-Modi",
                    vm.rates.joinToString(" / ") { "$it Hz" },
                    if (vm.maxHz > 60) Level.OK else Level.WARN
                )
                StatusRow(
                    "Hz-Steuerung",
                    if (canControl) "Schreibzugriff vorhanden" else "Berechtigung „Systemeinstellungen ändern“ fehlt",
                    if (canControl) Level.OK else Level.BAD
                )
                StatusRow("Wirkung am Display", vText, vLevel)
                StatusRow(
                    "Automatik pro App",
                    if (p.usage) "Nutzungszugriff erteilt" else "Nutzungszugriff fehlt",
                    if (p.usage) Level.OK else Level.WARN
                )
                StatusRow(
                    "Game-Overlay",
                    if (p.overlay) "Berechtigung erteilt" else "Overlay-Berechtigung fehlt",
                    if (p.overlay) Level.OK else Level.WARN
                )
                StatusRow(
                    "Funktionsstufe",
                    when {
                        s.useRoot -> "Root-Modus"
                        p.secure -> "Advanced (ADB-Grant)"
                        else -> "Standard"
                    },
                    Level.OK
                )
                if (vm.maxHz <= 60) {
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Dieses Display bietet nur 60 Hz. Mehr kann keine App freischalten – es werden nur vorhandene Hardware-Modi genutzt.",
                        color = Muted, fontSize = 12.sp
                    )
                }
            }
        }
    }
}

// ======================================================================================
// GAME TURBO
// ======================================================================================
@Composable
fun GameTurboScreen(vm: MainViewModel, pad: PaddingValues) {
    val s by vm.settings.collectAsStateWithLifecycle()
    val rt by vm.runtime.collectAsStateWithLifecycle()
    val hz by vm.hz.collectAsStateWithLifecycle()
    val games by vm.games.collectAsStateWithLifecycle()
    val apps by vm.apps.collectAsStateWithLifecycle()
    val appName = apps.firstOrNull { it.pkg == rt.foreground }?.label ?: "–"
    var showAdd by remember { mutableStateOf(false) }

    ScreenList("Game Turbo", "Spielebibliothek mit eigenen Profilen", pad) {
        item {
            TlCard {
                Caps("Performance-Dashboard")
                Spacer(Modifier.height(8.dp))
                Row {
                    Column(Modifier.weight(1f)) { Text("$hz Hz", fontSize = 32.sp, fontWeight = FontWeight.Light); Text("aktuell", color = Muted, fontSize = 12.sp) }
                    Column(Modifier.weight(2f)) { Text(rt.applied, fontSize = 16.sp); Text("Vordergrund: $appName", color = Muted, fontSize = 12.sp) }
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    "Hier werden nur echte Messwerte der Bildwiederholrate gezeigt. TL 120Hz übertaktet weder CPU/GPU noch gibt es RAM frei.",
                    color = Muted, fontSize = 12.sp
                )
            }
        }
        item {
            TlCard {
                SwitchRow("Spiele automatisch auf Ultra Refresh", s.gameAuto) { vm.setGameAuto(it) }
                SwitchRow("Schwebendes Overlay in Spielen", s.overlayEnabled) { vm.setOverlay(it) }
            }
        }
        items(games, key = { it.pkg }) { g ->
            val prof = s.profiles[g.pkg]
            val mode = prof?.takeIf { it.enabled }?.mode ?: if (s.gameAuto) PerfMode.ULTRA else null
            val limited = rt.limited[g.pkg]
            TlCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    AppIcon(g.pkg)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(g.label, fontSize = 16.sp, maxLines = 1)
                        Text(g.pkg, color = Muted, fontSize = 11.sp, maxLines = 1)
                    }
                    TextButton(onClick = { vm.removeGame(g.pkg) }) { Text("Entfernen", color = Muted) }
                }
                Spacer(Modifier.height(10.dp))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PerfMode.values().forEach { m ->
                        Pill(m.label, mode == m) { vm.setMode(g.pkg, m) }
                    }
                }
                if (limited != null) {
                    Spacer(Modifier.height(8.dp))
                    Text("Gemessen nur $limited Hz – Anfrage wird vom System/Hersteller nicht umgesetzt.", color = Bad, fontSize = 12.sp)
                }
            }
        }
        item {
            Pill("+ Spiel hinzufügen", false) { showAdd = true }
        }
        if (games.isEmpty()) {
            item { Text("Keine Spiele erkannt. Füge Spiele manuell hinzu.", color = Muted, fontSize = 13.sp) }
        }
    }

    if (showAdd) {
        var q by remember { mutableStateOf("") }
        val gamePkgs = games.map { it.pkg }.toSet()
        val candidates = apps.filter { it.pkg !in gamePkgs && it.label.contains(q, ignoreCase = true) }
        AlertDialog(
            onDismissRequest = { showAdd = false },
            containerColor = Surface1,
            confirmButton = { TextButton(onClick = { showAdd = false }) { Text("Schließen") } },
            title = { Text("Spiel hinzufügen") },
            text = {
                Column {
                    OutlinedTextField(q, { q = it }, singleLine = true, placeholder = { Text("Suchen") })
                    Spacer(Modifier.height(8.dp))
                    LazyColumn(Modifier.height(320.dp)) {
                        items(candidates, key = { it.pkg }) { a ->
                            Row(
                                Modifier.fillMaxWidth().clickable { vm.addGame(a.pkg); showAdd = false }.padding(vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                AppIcon(a.pkg, 36.dp)
                                Spacer(Modifier.width(12.dp))
                                Text(a.label, maxLines = 1)
                            }
                        }
                    }
                }
            }
        )
    }
}

@Composable
fun SwitchRow(title: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, Modifier.weight(1f), fontSize = 15.sp)
        Switch(
            checked, onChange,
            colors = SwitchDefaults.colors(checkedTrackColor = Accent, checkedThumbColor = Color(0xFF000000))
        )
    }
}

// ======================================================================================
// APPLICATIONS
// ======================================================================================
@Composable
fun ApplicationsScreen(vm: MainViewModel, pad: PaddingValues) {
    val s by vm.settings.collectAsStateWithLifecycle()
    val rt by vm.runtime.collectAsStateWithLifecycle()
    val apps by vm.apps.collectAsStateWithLifecycle()
    var q by remember { mutableStateOf("") }
    var filter by remember { mutableIntStateOf(0) }
    var open by remember { mutableStateOf<String?>(null) }

    val list = apps.filter { a ->
        a.label.contains(q, ignoreCase = true) && when (filter) {
            1 -> a.pkg in s.profiles
            2 -> a.pkg in s.blacklist
            else -> true
        }
    }

    ScreenList("Applications", "Profil pro App · Ausnahmen", pad) {
        item {
            OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("App suchen") })
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Pill("Alle", filter == 0) { filter = 0 }
                Pill("Mit Profil", filter == 1) { filter = 1 }
                Pill("Ausgeschlossen", filter == 2) { filter = 2 }
            }
        }
        items(list, key = { it.pkg }) { a ->
            val prof = s.profiles[a.pkg]
            val black = a.pkg in s.blacklist
            val expanded = open == a.pkg
            TlCard(onClick = { open = if (expanded) null else a.pkg }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    AppIcon(a.pkg)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(a.label, fontSize = 16.sp, maxLines = 1)
                        Text(a.pkg, color = Muted, fontSize = 11.sp, maxLines = 1)
                    }
                    val badge = when {
                        black -> "Ausgeschlossen"
                        prof != null -> prof.mode.label
                        else -> null
                    }
                    if (badge != null) Text(badge, color = Accent, fontSize = 12.sp)
                }
                rt.limited[a.pkg]?.let {
                    Spacer(Modifier.height(6.dp))
                    Text("Gemessen nur $it Hz bei dieser App", color = Bad, fontSize = 12.sp)
                }
                if (expanded) {
                    Spacer(Modifier.height(12.dp))
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Pill("Kein Profil", prof == null) { vm.removeProfile(a.pkg) }
                        PerfMode.values().forEach { m -> Pill(m.label, prof?.mode == m) { vm.setMode(a.pkg, m) } }
                    }
                    if (prof?.mode == PerfMode.PERFORMANCE) {
                        Spacer(Modifier.height(8.dp))
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            vm.rates.forEach { r -> Pill("$r Hz", prof?.hz == r) { vm.setProfileHz(a.pkg, r) } }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    SwitchRow("Ausschließen (Systemstandard erzwingen)", black) { vm.toggleBlacklist(a.pkg) }
                }
            }
        }
        if (list.isEmpty()) item { Text("Keine Apps gefunden.", color = Muted) }
    }
}

// ======================================================================================
// REFRESH RATE
// ======================================================================================
@Composable
fun RefreshRateScreen(vm: MainViewModel, pad: PaddingValues) {
    val s by vm.settings.collectAsStateWithLifecycle()
    val rt by vm.runtime.collectAsStateWithLifecycle()
    val hz by vm.hz.collectAsStateWithLifecycle()
    val effective = if (!s.global.enabled) 0 else if (s.global.mode == PerfMode.ULTRA) vm.maxHz else s.global.hz
    val all = (listOf(60, 90, 120) + vm.rates).distinct().sorted()
    val (vText, vLevel) = verifyText(rt.verify, rt.observedHz)

    ScreenList("Refresh Rate", "Nur Modi, die dein Display wirklich hat", pad) {
        item {
            TlCard {
                Caps("Aktuell")
                Text("$hz Hz", fontSize = 48.sp, fontWeight = FontWeight.Light)
                Text(
                    if (s.global.enabled) "Angefordert: ${s.global.mode.label}" + (if (effective > 0) " · $effective Hz" else "")
                    else "Angefordert: Systemstandard",
                    color = Muted, fontSize = 13.sp
                )
            }
        }
        item {
            TlCard {
                Caps("Rate wählen")
                Spacer(Modifier.height(10.dp))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    all.forEach { r ->
                        Pill("$r Hz", s.global.enabled && s.global.mode != PerfMode.BALANCED && effective == r, enabled = r in vm.rates) {
                            vm.setGlobalHz(r)
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Pill("Balanced", s.global.enabled && s.global.mode == PerfMode.BALANCED) { vm.setGlobalBalanced() }
                    Pill("Systemstandard", !s.global.enabled) { vm.resetGlobal() }
                }
                Spacer(Modifier.height(10.dp))
                Text(
                    "Nicht verfügbare Raten sind deaktiviert. Eine feste Rate setzt Minimum und Maximum der Anzeige; Balanced lässt dem System den Spielraum.",
                    color = Muted, fontSize = 12.sp
                )
            }
        }
        item {
            TlCard {
                Caps("Wirkung")
                Spacer(Modifier.height(6.dp))
                StatusRow("Messung nach dem Anwenden", vText, vLevel)
                if (rt.route.isNotEmpty()) StatusRow("Schreibweg", rt.route, Level.OK)
                if (vm.vendorKeys.isNotEmpty()) StatusRow("Herstellerschlüssel gefunden", vm.vendorKeys.joinToString(), Level.OK)
            }
        }
        item {
            TlCard {
                Caps("Display-Modi des Geräts")
                Spacer(Modifier.height(6.dp))
                vm.modeLines.forEach { Text(it, color = Muted, fontSize = 12.sp) }
            }
        }
    }
}

// ======================================================================================
// SETTINGS
// ======================================================================================
@Composable
fun SettingsScreen(vm: MainViewModel, pad: PaddingValues) {
    val ctx = LocalContext.current
    val s by vm.settings.collectAsStateWithLifecycle()
    val rt by vm.runtime.collectAsStateWithLifecycle()
    val p by vm.perms.collectAsStateWithLifecycle()
    val root by vm.rootState.collectAsStateWithLifecycle()
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { vm.refreshPerms() }

    ScreenList("Settings", "Berechtigungen und Dienst", pad) {
        item {
            TlCard {
                Caps("Hintergrunddienst")
                Spacer(Modifier.height(4.dp))
                SwitchRow("Dienst aktiv" + if (rt.serviceRunning) " (läuft)" else "", s.serviceEnabled) { vm.setService(it) }
                SwitchRow("Nach Neustart automatisch starten", s.autoStart) { vm.setAutoStart(it) }
            }
        }
        item {
            TlCard {
                Caps("Berechtigungen")
                Spacer(Modifier.height(4.dp))
                PermRow("Systemeinstellungen ändern", "Nötig, um Hz-Wünsche an Android zu senden", p.writeSettings) {
                    ctx.startActivity(Perms.writeSettingsIntent(ctx))
                }
                PermRow("Nutzungszugriff", "Nötig für automatische Profile pro App", p.usage) {
                    ctx.startActivity(Perms.usageIntent())
                }
                PermRow("Über anderen Apps anzeigen", "Nötig für das Game-Overlay", p.overlay) {
                    ctx.startActivity(Perms.overlayIntent(ctx))
                }
                PermRow("Benachrichtigungen", "Für die Dienst-Benachrichtigung", p.notif) {
                    if (Build.VERSION.SDK_INT >= 33) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
            }
        }
        item {
            TlCard {
                Caps("Advanced (ADB)")
                Spacer(Modifier.height(6.dp))
                StatusRow(
                    "WRITE_SECURE_SETTINGS",
                    if (p.secure) "Erteilt" else "Optional – einmalig per Computer erteilen:",
                    if (p.secure) Level.OK else Level.WARN
                )
                if (!p.secure) {
                    Text(Perms.ADB_SECURE, color = Accent, fontSize = 12.sp)
                    TextButton(onClick = {
                        val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        cm.setPrimaryClip(ClipData.newPlainText("adb", Perms.ADB_SECURE))
                    }) { Text("Befehl kopieren") }
                }
            }
        }
        item {
            TlCard {
                Caps("Root")
                Spacer(Modifier.height(4.dp))
                SwitchRow("Root-Modus verwenden", s.useRoot) { vm.setRoot(it) }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = { vm.checkRoot() }) { Text("Root prüfen") }
                    Text(
                        when (root) { true -> "Root verfügbar"; false -> "Kein Root"; null -> "" },
                        color = if (root == true) Good else Muted, fontSize = 13.sp
                    )
                }
                Text(
                    "Root wird nur genutzt, wenn die normalen Schreibwege fehlschlagen. Vorherige Werte werden gesichert und können wiederhergestellt werden.",
                    color = Muted, fontSize = 12.sp
                )
            }
        }
        item {
            TlCard {
                Caps("Protokoll")
                Spacer(Modifier.height(6.dp))
                if (rt.log.isEmpty()) Text("Noch keine Einträge.", color = Muted, fontSize = 12.sp)
                rt.log.takeLast(12).reversed().forEach { Text(it, color = Muted, fontSize = 12.sp) }
            }
        }
        item {
            TlCard {
                Caps("Hinweis")
                Spacer(Modifier.height(6.dp))
                Text(
                    "TL 120Hz kann nur Raten nutzen, die dein Display in Hardware besitzt. Ob ein Hersteller (Xiaomi, Samsung, OnePlus …) die Anfrage umsetzt, wird nach jedem Anwenden am echten Display gemessen und oben angezeigt.",
                    color = Muted, fontSize = 12.sp
                )
            }
        }
    }
}

@Composable
private fun PermRow(title: String, detail: String, granted: Boolean, onGrant: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            StatusRow(title, detail, if (granted) Level.OK else Level.WARN)
        }
        if (!granted) TextButton(onClick = onGrant) { Text("Erteilen") }
    }
}
