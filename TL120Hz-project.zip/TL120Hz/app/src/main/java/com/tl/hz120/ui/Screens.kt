package com.tl.hz120.ui

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tl.hz120.data.PerfMode
import com.tl.hz120.data.Verify
import com.tl.hz120.system.Perms

private fun verifyText(v: Verify, observed: Int): Pair<String, Level> = when (v) {
    Verify.CONFIRMED -> "Bestätigt: Das Display läuft mit der angeforderten Rate ($observed Hz)." to Level.OK
    Verify.NOT_CONFIRMED -> "Nicht bestätigt: System oder Hersteller ignoriert die Anfrage (gemessen: $observed Hz)." to Level.BAD
    Verify.NO_ROUTE -> "Keine Schreib-Berechtigung – siehe Einstellungen." to Level.BAD
    Verify.UNKNOWN -> "Noch nicht getestet." to Level.WARN
}

// ======================================================================================
// HOME
// ======================================================================================
@Composable
fun HomeScreen(vm: MainViewModel, pad: PaddingValues) {
    val s by vm.settings.collectAsStateWithLifecycle()
    val rt by vm.runtime.collectAsStateWithLifecycle()
    val hz by vm.hz.collectAsStateWithLifecycle()
    val p by vm.perms.collectAsStateWithLifecycle()
    val games by vm.games.collectAsStateWithLifecycle()
    val (vText, vLevel) = verifyText(rt.verify, rt.observedHz)
    val canControl = p.writeSettings || p.secure || s.useRoot
    // Abgeleitete Werte nur bei Änderung neu berechnen, nicht bei jeder Recomposition.
    val ratesText = remember(vm.rates) { vm.rates.joinToString(" / ") { "$it Hz" } }
    val activeProfiles = remember(s.profiles) { s.profiles.values.count { it.enabled } }

    ScreenList("TL120Hz", "Bildwiederholrate, Profile, Game Turbo", pad) {
        item {
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                HzRing(hz, vm.maxHz, s.global.enabled) { vm.setUltra(!s.global.enabled) }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(TlSpace.sm)) {
                Stat("Aktuell", "$hz Hz", Modifier.weight(1f))
                Stat("Maximal", "${vm.maxHz} Hz", Modifier.weight(1f))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(TlSpace.sm)) {
                Stat("Modus", rt.applied, Modifier.weight(1f))
                Stat("Spiele", "${games.size}", Modifier.weight(1f))
            }
        }
        item { Stat("Aktive App-Profile", "$activeProfiles") }
        item {
            TlCard {
                Caps("Kompatibilität auf diesem Gerät")
                Spacer(Modifier.height(TlSpace.xs))
                StatusRow(
                    "Display-Modi",
                    ratesText,
                    if (vm.maxHz > 60) Level.OK else Level.WARN
                )
                StatusRow(
                    "Hz-Steuerung",
                    if (canControl) "Schreibzugriff vorhanden" else "Berechtigung „Systemeinstellungen ändern“ fehlt",
                    if (canControl) Level.OK else Level.BAD
                )
                StatusRow("Wirkung am Display", vText, vLevel)
                StatusRow(
                    "Automatik pro App",
                    if (p.usage) "Nutzungszugriff erteilt" else "Nutzungszugriff fehlt",
                    if (p.usage) Level.OK else Level.WARN
                )
                StatusRow(
                    "Game-Overlay",
                    if (p.overlay) "Berechtigung erteilt" else "Overlay-Berechtigung fehlt",
                    if (p.overlay) Level.OK else Level.WARN
                )
                StatusRow(
                    "Funktionsstufe",
                    when {
                        s.useRoot -> "Root-Modus"
                        p.secure -> "Advanced (ADB-Grant)"
                        else -> "Standard"
                    },
                    Level.OK
                )
                if (vm.maxHz <= 60) {
                    Spacer(Modifier.height(TlSpace.xs))
                    Text(
                        "Dieses Display bietet nur 60 Hz. Mehr kann keine App freischalten – es werden nur vorhandene Hardware-Modi genutzt.",
                        color = Muted, style = TlType.caption
                    )
                }
            }
        }
    }
}

// ======================================================================================
// GAME TURBO
// ======================================================================================
@Composable
fun GameTurboScreen(vm: MainViewModel, pad: PaddingValues) {
    val s by vm.settings.collectAsStateWithLifecycle()
    val rt by vm.runtime.collectAsStateWithLifecycle()
    val hz by vm.hz.collectAsStateWithLifecycle()
    val games by vm.games.collectAsStateWithLifecycle()
    val apps by vm.apps.collectAsStateWithLifecycle()
    val appName = remember(apps, rt.foreground) { apps.firstOrNull { it.pkg == rt.foreground }?.label ?: "–" }
    var showAdd by remember { mutableStateOf(false) }

    ScreenList("Game Turbo", "Spielebibliothek mit eigenen Profilen", pad) {
        item {
            TlCard {
                Caps("Performance-Dashboard")
                Spacer(Modifier.height(TlSpace.xs))
                Row {
                    Column(Modifier.weight(1f)) { Text("$hz Hz", style = TlType.hero); Text("aktuell", color = Muted, style = TlType.caption) }
                    Column(Modifier.weight(2f)) { Text(rt.applied, style = TlType.title); Text("Vordergrund: $appName", color = Muted, style = TlType.caption) }
                }
                Spacer(Modifier.height(TlSpace.xs))
                Text(
                    "Hier werden nur echte Messwerte der Bildwiederholrate gezeigt. TL120Hz übertaktet weder CPU/GPU noch gibt es RAM frei.",
                    color = Muted, style = TlType.caption
                )
            }
        }
        item {
            TlCard {
                TlSwitchRow("Spiele automatisch auf Ultra Refresh", s.gameAuto) { vm.setGameAuto(it) }
                TlSwitchRow("Schwebendes Overlay in Spielen", s.overlayEnabled) { vm.setOverlay(it) }
            }
        }
        items(games, key = { it.pkg }) { g ->
            val prof = s.profiles[g.pkg]
            val mode = prof?.takeIf { it.enabled }?.mode ?: if (s.gameAuto) PerfMode.ULTRA else null
            val limited = rt.limited[g.pkg]
            TlCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    AppIcon(g.pkg)
                    Spacer(Modifier.width(TlSpace.sm))
                    Column(Modifier.weight(1f)) {
                        Text(g.label, style = TlType.title, maxLines = 1)
                        Text(g.pkg, color = Muted, style = TlType.caption, maxLines = 1)
                        if (g.gameSource != com.tl.hz120.data.GameSource.NONE) {
                            Text(g.gameSource.label, color = Muted, style = TlType.caption, maxLines = 1)
                        }
                    }
                    TlTextAction("Entfernen", ActionTone.Secondary) { vm.removeGame(g.pkg) }
                }
                Spacer(Modifier.height(TlSpace.chip))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(TlSpace.xs)) {
                    PerfMode.values().forEach { m ->
                        Pill(m.label, mode == m) { vm.setMode(g.pkg, m) }
                    }
                }
                if (limited != null) {
                    Spacer(Modifier.height(TlSpace.xs))
                    Text("Gemessen nur $limited Hz – Anfrage wird vom System/Hersteller nicht umgesetzt.", color = Bad, style = TlType.caption)
                }
            }
        }
        item {
            Pill("+ Spiel hinzufügen", false) { showAdd = true }
        }
        if (games.isEmpty()) {
            item { EmptyState("Keine Spiele erkannt", "Füge Spiele manuell hinzu.") }
        }
    }

    if (showAdd) {
        var q by remember { mutableStateOf("") }
        // Kandidaten nur neu filtern, wenn sich Suche, Apps oder Spiele ändern.
        val candidates = remember(apps, games, q) {
            val gamePkgs = games.mapTo(HashSet()) { it.pkg }
            apps.filter { it.pkg !in gamePkgs && it.label.contains(q, ignoreCase = true) }
        }
        TlDialog(
            title = "Spiel hinzufügen",
            onDismiss = { showAdd = false },
            text = {
                Column {
                    TlSearchField(q, { q = it }, "Suchen", Modifier.fillMaxWidth())
                    Spacer(Modifier.height(TlSpace.xs))
                    LazyColumn(Modifier.height(320.dp)) {
                        items(candidates, key = { it.pkg }) { a ->
                            Row(
                                Modifier.fillMaxWidth().clickable { vm.addGame(a.pkg); showAdd = false }.padding(vertical = TlSpace.xs),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                AppIcon(a.pkg, TlSize.appIconSmall)
                                Spacer(Modifier.width(TlSpace.sm))
                                Text(a.label, maxLines = 1)
                            }
                        }
                    }
                }
            }
        )
    }
}


// ======================================================================================
// APPLICATIONS
// ======================================================================================
@Composable
fun ApplicationsScreen(vm: MainViewModel, pad: PaddingValues) {
    val s by vm.settings.collectAsStateWithLifecycle()
    val rt by vm.runtime.collectAsStateWithLifecycle()
    val apps by vm.apps.collectAsStateWithLifecycle()
    var q by remember { mutableStateOf("") }
    var filter by remember { mutableIntStateOf(0) }
    var open by remember { mutableStateOf<String?>(null) }

    // Filterliste nur neu berechnen, wenn sich Suche, Filter, Apps, Profile oder Ausnahmen ändern.
    val list = remember(apps, q, filter, s.profiles, s.blacklist) {
        apps.filter { a ->
            a.label.contains(q, ignoreCase = true) && when (filter) {
                1 -> a.pkg in s.profiles
                2 -> a.pkg in s.blacklist
                else -> true
            }
        }
    }

    ScreenList("Applications", "Profil pro App · Ausnahmen", pad) {
        item {
            TlSearchField(q, { q = it }, "App suchen", Modifier.fillMaxWidth())
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(TlSpace.xs)) {
                Pill("Alle", filter == 0) { filter = 0 }
                Pill("Mit Profil", filter == 1) { filter = 1 }
                Pill("Ausgeschlossen", filter == 2) { filter = 2 }
            }
        }
        items(list, key = { it.pkg }) { a ->
            val prof = s.profiles[a.pkg]
            val black = a.pkg in s.blacklist
            val expanded = open == a.pkg
            TlCard(onClick = { open = if (expanded) null else a.pkg }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    AppIcon(a.pkg)
                    Spacer(Modifier.width(TlSpace.sm))
                    Column(Modifier.weight(1f)) {
                        Text(a.label, style = TlType.title, maxLines = 1)
                        Text(a.pkg, color = Muted, style = TlType.caption, maxLines = 1)
                    }
                    val badge = when {
                        black -> "Ausgeschlossen"
                        prof != null -> prof.mode.label
                        else -> null
                    }
                    if (badge != null) Text(badge, color = Accent, style = TlType.caption)
                }
                rt.limited[a.pkg]?.let {
                    Spacer(Modifier.height(TlSpace.xs))
                    Text("Gemessen nur $it Hz bei dieser App", color = Bad, style = TlType.caption)
                }
                if (expanded) {
                    Spacer(Modifier.height(TlSpace.sm))
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(TlSpace.xs)) {
                        Pill("Kein Profil", prof == null) { vm.removeProfile(a.pkg) }
                        PerfMode.values().forEach { m -> Pill(m.label, prof?.mode == m) { vm.setMode(a.pkg, m) } }
                    }
                    if (prof?.mode == PerfMode.PERFORMANCE) {
                        Spacer(Modifier.height(TlSpace.xs))
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(TlSpace.xs)) {
                            vm.rates.forEach { r -> Pill("$r Hz", prof?.hz == r) { vm.setProfileHz(a.pkg, r) } }
                        }
                    }
                    Spacer(Modifier.height(TlSpace.xs))
                    TlSwitchRow("Ausschließen (Systemstandard erzwingen)", black) { vm.toggleBlacklist(a.pkg) }
                }
            }
        }
        if (list.isEmpty()) item { EmptyState("Keine Apps gefunden", "Suche oder Filter anpassen.") }
    }
}

// ======================================================================================
// REFRESH RATE
// ======================================================================================
@Composable
fun RefreshRateScreen(vm: MainViewModel, pad: PaddingValues) {
    val s by vm.settings.collectAsStateWithLifecycle()
    val rt by vm.runtime.collectAsStateWithLifecycle()
    val hz by vm.hz.collectAsStateWithLifecycle()
    val effective = if (!s.global.enabled) 0 else if (s.global.mode == PerfMode.ULTRA) vm.maxHz else s.global.hz
    val all = remember(vm.rates) { (listOf(60, 90, 120) + vm.rates).distinct().sorted() }
    val (vText, vLevel) = verifyText(rt.verify, rt.observedHz)

    ScreenList("Refresh Rate", "Nur Modi, die dein Display wirklich hat", pad) {
        item {
            TlCard {
                Caps("Aktuell")
                Text("$hz Hz", style = TlType.metric)
                Text(
                    if (s.global.enabled) "Angefordert: ${s.global.mode.label}" + (if (effective > 0) " · $effective Hz" else "")
                    else "Angefordert: Systemstandard",
                    color = Muted, style = TlType.bodySmall
                )
            }
        }
        item { SectionHeader("Diagnose") }
        item {
            val l by vm.live.collectAsStateWithLifecycle()
            TlCard {
                Caps("Live Monitor")
                Spacer(Modifier.height(TlSpace.xs))
                val v = l
                if (v == null) {
                    LoadingHint("Messung läuft …")
                } else {
                    InfoRow("Rate", String.format(java.util.Locale.US, "%.1f Hz", v.hz) + String.format(java.util.Locale.US, " · Modus %.1f Hz", v.modeHz))
                    InfoRow("Auflösung", v.resolution)
                    InfoRow("Temperatur", v.thermal.label + (v.batteryTempC?.let { String.format(java.util.Locale.US, " · Akku %.1f °C", it) } ?: ""))
                    InfoRow("Akku", (if (v.batteryPct >= 0) "${v.batteryPct} %" else "unbekannt") + if (v.charging) " · lädt" else "")
                    InfoRow("Energiesparen", if (v.powerSave) "an" else "aus")
                    InfoRow("RAM frei", "${v.availMemMb} MB" + if (v.lowMemory) " · knapp" else "")
                    if (v.thermal.throttled) {
                        StatusRow("Drosselung möglich", "Das Gerät ist ${v.thermal.label.lowercase()}. Hohe Raten können dann nicht gehalten werden.", Level.WARN)
                    }
                }
            }
        }
        item {
            TlCard {
                Caps("Rate wählen")
                Spacer(Modifier.height(TlSpace.chip))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(TlSpace.xs)) {
                    all.forEach { r ->
                        Pill("$r Hz", s.global.enabled && s.global.mode != PerfMode.BALANCED && effective == r, enabled = r in vm.rates) {
                            vm.setGlobalHz(r)
                        }
                    }
                }
                Spacer(Modifier.height(TlSpace.chip))
                Row(horizontalArrangement = Arrangement.spacedBy(TlSpace.xs)) {
                    Pill("Balanced", s.global.enabled && s.global.mode == PerfMode.BALANCED) { vm.setGlobalBalanced() }
                    Pill("Systemstandard", !s.global.enabled) { vm.resetGlobal() }
                }
                Spacer(Modifier.height(TlSpace.chip))
                Text(
                    "Nicht verfügbare Raten sind deaktiviert. Eine feste Rate setzt Minimum und Maximum der Anzeige; Balanced lässt dem System den Spielraum.",
                    color = Muted, style = TlType.caption
                )
            }
        }
        item {
            TlCard {
                Caps("Wirkung")
                Spacer(Modifier.height(TlSpace.xs))
                StatusRow("Messung nach dem Anwenden", vText, vLevel)
                if (rt.route.isNotEmpty()) StatusRow("Schreibweg", rt.route, Level.OK)
                if (vm.vendorKeys.isNotEmpty()) StatusRow("Herstellerschlüssel gefunden", vm.vendorKeys.joinToString(), Level.OK)
            }
        }
        item {
            val hw by vm.hardware.collectAsStateWithLifecycle()
            TlCard {
                Caps("Hardwareprofil")
                Spacer(Modifier.height(TlSpace.xs))
                val h = hw
                if (h == null) {
                    LoadingHint("Wird analysiert …")
                } else {
                    InfoRow("Gerät", "${h.manufacturer} ${h.model}".trim())
                    InfoRow("Android", "${h.androidRelease} (API ${h.sdkInt})" + if (h.securityPatch.isNotBlank()) " · Patch ${h.securityPatch}" else "")
                    InfoRow("Chipsatz", h.soc.ifBlank { "unbekannt" })
                    InfoRow("CPU / RAM", "${h.cpuCores} Kerne · ${h.ramTotalMb} MB")
                    InfoRow("Display", "${h.displayWidth}×${h.displayHeight} · ${h.densityDpi} dpi")
                    InfoRow("Raten", h.refreshRates.joinToString(" / ") { "$it Hz" } + if (h.variableRefresh) " · variabel" else "")
                    InfoRow("Hersteller-Familie", h.vendorFamily)
                    val c by vm.compat.collectAsStateWithLifecycle()
                    c?.let { e ->
                        Spacer(Modifier.height(TlSpace.xs))
                        StatusRow(
                            "Kompatibilität: ${e.title}",
                            (if (e.verified) "" else "Nicht am Gerät bestätigt. ") + e.notes.joinToString(" "),
                            if (e.verified) Level.OK else Level.WARN
                        )
                    }
                }
                Spacer(Modifier.height(TlSpace.xxs))
                TlTextAction("Neu scannen", ActionTone.Secondary) { vm.rescanHardware() }
            }
        }
        item {
            TlCard {
                Caps("Display-Modi des Geräts")
                Spacer(Modifier.height(TlSpace.xs))
                vm.modeLines.forEach { Text(it, color = Muted, style = TlType.caption) }
            }
        }
    }
}

// ======================================================================================
// SETTINGS
// ======================================================================================
@Composable
fun SettingsScreen(vm: MainViewModel, pad: PaddingValues) {
    val ctx = LocalContext.current
    val s by vm.settings.collectAsStateWithLifecycle()
    val rt by vm.runtime.collectAsStateWithLifecycle()
    val p by vm.perms.collectAsStateWithLifecycle()
    val root by vm.rootState.collectAsStateWithLifecycle()
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { vm.refreshPerms() }
    // Protokoll nur neu aufbereiten, wenn sich der Log ändert.
    val recentLog = remember(rt.log) { rt.log.takeLast(12).reversed() }

    ScreenList("Settings", "Berechtigungen und Dienst", pad) {
        item {
            TlCard {
                Caps("Hintergrunddienst")
                Spacer(Modifier.height(TlSpace.xxs))
                TlSwitchRow("Dienst aktiv" + if (rt.serviceRunning) " (läuft)" else "", s.serviceEnabled) { vm.setService(it) }
                TlSwitchRow("Nach Neustart automatisch starten", s.autoStart) { vm.setAutoStart(it) }
            }
        }
        item {
            TlCard {
                Caps("Berechtigungen")
                Spacer(Modifier.height(TlSpace.xxs))
                PermRow("Systemeinstellungen ändern", "Nötig, um Hz-Wünsche an Android zu senden", p.writeSettings) {
                    ctx.startActivity(Perms.writeSettingsIntent(ctx))
                }
                PermRow("Nutzungszugriff", "Nötig für automatische Profile pro App", p.usage) {
                    ctx.startActivity(Perms.usageIntent())
                }
                PermRow("Über anderen Apps anzeigen", "Nötig für das Game-Overlay", p.overlay) {
                    ctx.startActivity(Perms.overlayIntent(ctx))
                }
                PermRow("Benachrichtigungen", "Für die Dienst-Benachrichtigung", p.notif) {
                    if (Build.VERSION.SDK_INT >= 33) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
            }
        }
        item {
            TlCard {
                Caps("Advanced (ADB)")
                Spacer(Modifier.height(TlSpace.xs))
                StatusRow(
                    "WRITE_SECURE_SETTINGS",
                    if (p.secure) "Erteilt" else "Optional – einmalig per Computer erteilen:",
                    if (p.secure) Level.OK else Level.WARN
                )
                if (!p.secure) {
                    Text(Perms.ADB_SECURE, color = Accent, style = TlType.caption)
                    TlTextAction("Befehl kopieren") {
                        val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        cm.setPrimaryClip(ClipData.newPlainText("adb", Perms.ADB_SECURE))
                    }
                }
            }
        }
        item {
            TlCard {
                Caps("Root")
                Spacer(Modifier.height(TlSpace.xxs))
                TlSwitchRow("Root-Modus verwenden", s.useRoot) { vm.setRoot(it) }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TlTextAction("Root prüfen") { vm.checkRoot() }
                    Text(
                        when (root) { true -> "Root verfügbar"; false -> "Kein Root"; null -> "" },
                        color = if (root == true) Good else Muted, style = TlType.bodySmall
                    )
                }
                Text(
                    "Root wird nur genutzt, wenn die normalen Schreibwege fehlschlagen. Vorherige Werte werden gesichert und können wiederhergestellt werden.",
                    color = Muted, style = TlType.caption
                )
            }
        }
        item {
            TlCard {
                Caps("Protokoll")
                Spacer(Modifier.height(TlSpace.xs))
                if (rt.log.isEmpty()) Text("Noch keine Einträge.", color = Muted, style = TlType.caption)
                recentLog.forEach { Text(it, color = Muted, style = TlType.caption) }
            }
        }
        item {
            TlCard {
                Caps("Hinweis")
                Spacer(Modifier.height(TlSpace.xs))
                Text(
                    "TL120Hz kann nur Raten nutzen, die dein Display in Hardware besitzt. Ob ein Hersteller (Xiaomi, Samsung, OnePlus …) die Anfrage umsetzt, wird nach jedem Anwenden am echten Display gemessen und oben angezeigt.",
                    color = Muted, style = TlType.caption
                )
            }
        }
    }
}

@Composable
private fun PermRow(title: String, detail: String, granted: Boolean, onGrant: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            StatusRow(title, detail, if (granted) Level.OK else Level.WARN)
        }
        if (!granted) TlTextAction("Erteilen", onClick = onGrant)
    }
}

