package com.tl.hz120

import android.app.Application
import com.tl.hz120.data.RtState
import com.tl.hz120.data.Store
import com.tl.hz120.system.AppScanner
import com.tl.hz120.system.DisplayEngine
import com.tl.hz120.system.RefreshController
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update

class TlApp : Application() {
    val store by lazy { Store(this) }
    val engine by lazy { DisplayEngine(this) }
    val controller by lazy { RefreshController(this, store, engine) }
    val scanner by lazy { AppScanner(this) }
    val runtime = MutableStateFlow(RtState())

    fun log(msg: String) {
        runtime.update { it.copy(log = (it.log + msg).takeLast(40)) }
    }
}
