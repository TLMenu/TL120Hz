package com.tl.hz120.system

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import com.tl.hz120.data.AppInfo

class AppScanner(private val ctx: Context) {
    /** Alle Apps mit Launcher-Icon. Spiele werden über die Android-Kategorie "Game" erkannt. */
    @Suppress("DEPRECATION")
    fun scan(): List<AppInfo> {
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, 0)
            .map { it.activityInfo.applicationInfo }
            .distinctBy { it.packageName }
            .filter { it.packageName != ctx.packageName }
            .map {
                AppInfo(
                    it.packageName,
                    pm.getApplicationLabel(it).toString(),
                    it.category == ApplicationInfo.CATEGORY_GAME || (it.flags and ApplicationInfo.FLAG_IS_GAME) != 0
                )
            }
            .sortedBy { it.label.lowercase() }
    }
}
