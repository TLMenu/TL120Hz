package com.tl.hz120.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

val Bg = Color(0xFF07080A)
val Surface1 = Color(0xFF111318)
val Surface2 = Color(0xFF1A1D24)
val Line = Color(0xFF262A33)
val TextC = Color(0xFFEDEFF3)
val Muted = Color(0xFF8A90A0)
val Accent = Color(0xFFFF6B2C)
val Good = Color(0xFF4ADE80)
val Warn = Color(0xFFF5B83D)
val Bad = Color(0xFFFF5470)

private val scheme = darkColorScheme(
    primary = Accent, onPrimary = Color.Black,
    background = Bg, onBackground = TextC,
    surface = Surface1, onSurface = TextC,
    surfaceVariant = Surface2, onSurfaceVariant = Muted,
    outline = Line
)

private val type = Typography(
    bodyLarge = TextStyle(fontSize = 16.sp, color = TextC),
    bodyMedium = TextStyle(fontSize = 14.sp, color = TextC),
    labelLarge = TextStyle(fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
)

/** Dark Mode ist Standard und fest; die App ist bewusst nur dunkel gestaltet. */
@Composable
fun TlTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = scheme, typography = type, content = content)
}
