package com.tl.hz120.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Bg = Color(0xFF07080A)
val Surface1 = Color(0xFF111318)
val Surface2 = Color(0xFF1A1D24)
val Line = Color(0xFF262A33)
val TextC = Color(0xFFEDEFF3)
val Muted = Color(0xFF8A90A0)
val Accent = Color(0xFFFF6B2C)
val Good = Color(0xFF4ADE80)
val Warn = Color(0xFFF5B83D)
val Bad = Color(0xFFFF5470)

private val scheme = darkColorScheme(
    primary = Accent, onPrimary = Color.Black,
    background = Bg, onBackground = TextC,
    surface = Surface1, onSurface = TextC,
    surfaceVariant = Surface2, onSurfaceVariant = Muted,
    outline = Line
)

private val type = Typography(
    displayLarge = TlType.display.copy(color = TextC),
    headlineMedium = TlType.headline.copy(color = TextC),
    titleMedium = TlType.title.copy(color = TextC),
    bodyLarge = TlType.body.copy(color = TextC),
    bodyMedium = TlType.bodySmall.copy(color = TextC),
    labelLarge = TlType.label,
    labelSmall = TlType.overline
)

private val shapes = Shapes(
    small = TlRadius.icon,
    medium = TlRadius.card,
    large = TlRadius.card,
    extraLarge = TlRadius.card
)

/** Dark Mode ist Standard und fest; die App ist bewusst nur dunkel gestaltet. */
@Composable
fun TlTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = scheme, typography = type, shapes = shapes, content = content)
}
