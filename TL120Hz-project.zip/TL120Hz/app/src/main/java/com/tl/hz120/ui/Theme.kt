package com.tl.hz120.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Bg = Color(0xFF05070B)
val Surface1 = Color(0xFF0D121A)
val Surface2 = Color(0xFF151C27)
val Line = Color(0xFF1E2735)
val TextC = Color(0xFFEDF3FA)
val Muted = Color(0xFF7D8AA0)
/** TL-Markenblau aus dem Logo. Ersetzt die frühere Akzentfarbe. */
val Brand = Color(0xFF1E8BFF)
val Good = Color(0xFF4ADE80)
val Warn = Color(0xFFF5B83D)
val Bad = Color(0xFFFF5470)

private val scheme = darkColorScheme(
    primary = Brand, onPrimary = Color.Black,
    background = Bg, onBackground = TextC,
    surface = Surface1, onSurface = TextC,
    surfaceVariant = Surface2, onSurfaceVariant = Muted,
    outline = Line
)

private val type = Typography(
    displayLarge = TlType.display.copy(color = TextC),
    headlineMedium = TlType.headline.copy(color = TextC),
    titleMedium = TlType.title.copy(color = TextC),
    bodyLarge = TlType.body.copy(color = TextC),
    bodyMedium = TlType.bodySmall.copy(color = TextC),
    labelLarge = TlType.label,
    labelSmall = TlType.overline
)

private val shapes = Shapes(
    small = TlRadius.icon,
    medium = TlRadius.card,
    large = TlRadius.card,
    extraLarge = TlRadius.card
)

/** Dark Mode ist Standard und fest; die App ist bewusst nur dunkel gestaltet. */
@Composable
fun TlTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = scheme, typography = type, shapes = shapes, content = content)
}
