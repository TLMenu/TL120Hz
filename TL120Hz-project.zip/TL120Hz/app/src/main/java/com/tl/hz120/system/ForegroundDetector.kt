package com.tl.hz120.system

import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.view.inputmethod.InputMethodManager

/** Erkennt die Vordergrund-App über UsageStatsManager (Sonderberechtigung "Nutzungszugriff"). */
class ForegroundDetector(private val ctx: Context) {
    private val usm = ctx.getSystemService(UsageStatsManager::class.java)
    private var last: String? = null
    private var lastTs = 0L

    private val launchers: Set<String> = try {
        @Suppress("DEPRECATION")
        ctx.packageManager.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0
        ).map { it.activityInfo.packageName }.toSet()
    } catch (_: Exception) {
        emptySet()
    }

    private val ignored: Set<String> = buildSet {
        add("com.android.systemui")
        try {
            ctx.getSystemService(InputMethodManager::class.java).enabledInputMethodList
                .forEach { add(it.packageName) }
        } catch (_: Exception) {
        }
    }

    fun reset() {
        lastTs = 0L
    }

    /** Liefert das Paket der zuletzt in den Vordergrund gekommenen App. */
    fun poll(): String? {
        val now = System.currentTimeMillis()
        val from = if (lastTs == 0L) now - 60_000 else lastTs - 500
        try {
            val events = usm.queryEvents(from, now)
            val e = UsageEvents.Event()
            while (events.hasNextEvent()) {
                events.getNextEvent(e)
                @Suppress("DEPRECATION")
                if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND && e.packageName !in ignored) {
                    last = e.packageName
                }
            }
        } catch (_: SecurityException) {
            return null
        }
        lastTs = now
        return last
    }

    /** Eigene App und Launcher zählen als "keine App" (→ globale Einstellung bzw. Systemstandard). */
    fun isNeutral(pkg: String?): Boolean = pkg == null || pkg == ctx.packageName || pkg in launchers
}
