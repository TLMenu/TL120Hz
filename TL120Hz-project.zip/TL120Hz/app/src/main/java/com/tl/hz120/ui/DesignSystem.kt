package com.tl.hz120.ui

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/*
 * TL120Hz Design-Tokens. Einzige Quelle für Abstände, Radien, Schriftgrößen, Größen und Animationszeiten.
 * Farben stehen in Theme.kt. Neue Werte gehören hierher, nicht in einzelne Screens.
 */

object TlSpace {
    val xxs: Dp = 4.dp
    val xs: Dp = 8.dp
    val sm: Dp = 12.dp
    val md: Dp = 16.dp
    val lg: Dp = 20.dp
    /** Vertikaler Innenabstand von Chips und Pills. */
    val chip: Dp = 10.dp
}

object TlRadius {
    val icon: Shape = RoundedCornerShape(10.dp)
    val card: Shape = RoundedCornerShape(20.dp)
    val pill: Shape = RoundedCornerShape(percent = 50)
}

object TlStroke {
    val hairline: Dp = 1.dp
}

object TlSize {
    val appIcon: Dp = 44.dp
    val appIconSmall: Dp = 36.dp
    val dot: Dp = 10.dp
    val ring: Dp = 240.dp
}

object TlMotion {
    const val fast = 150
    const val normal = 250
    const val ring = 600
}

object TlAlpha {
    const val disabled = 0.35f
}

/** Schriftskala. Ohne Farbe, die Farbe setzt der Aufrufer. */
object TlType {
    val display = TextStyle(fontSize = 72.sp, fontWeight = FontWeight.Light)
    val headline = TextStyle(fontSize = 30.sp, fontWeight = FontWeight.SemiBold, letterSpacing = (-0.5).sp)
    val hero = TextStyle(fontSize = 32.sp, fontWeight = FontWeight.Light)
    val metric = TextStyle(fontSize = 48.sp, fontWeight = FontWeight.Light)
    val stat = TextStyle(fontSize = 22.sp, fontWeight = FontWeight.Medium)
    val title = TextStyle(fontSize = 16.sp)
    val body = TextStyle(fontSize = 15.sp)
    val bodySmall = TextStyle(fontSize = 14.sp)
    val label = TextStyle(fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
    val caption = TextStyle(fontSize = 12.sp)
    val overline = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Medium, letterSpacing = 1.3.sp)
}
