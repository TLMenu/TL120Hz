# TL 120Hz

Android-App (Kotlin, Jetpack Compose, MVVM) zum Anfordern der höchsten Bildwiederholrate
deines Displays – systemweit, pro App und pro Spiel – mit einem Game-Turbo-Bereich.

## Was die App kann – und was nicht

- Sie nutzt nur Display-Modi, die dein Gerät in Hardware hat. Auf einem 60-Hz-Display passiert nichts.
- Android erlaubt normalen Apps keinen direkten Zugriff auf fremde Fenster oder die Display-Treiber.
  TL 120Hz schreibt deshalb die Wünsche `min_refresh_rate` / `peak_refresh_rate` in die Systemeinstellungen
  (Berechtigung „Systemeinstellungen ändern“). Ob dein Hersteller das umsetzt, **misst die App nach jedem
  Anwenden am echten Display** und zeigt es unter Home → Kompatibilität und Refresh Rate → Wirkung an.
  Setzt ein Gerät die Anfrage nicht um (häufig bei manchen Samsung-/OEM-ROMs), steht dort „Nicht bestätigt“.
- Herstellerspezifische Schlüssel (`user_refresh_rate`, `miui_refresh_rate`) werden nur angefasst, wenn sie auf
  dem Gerät bereits existieren.
- Kein CPU/GPU-Overclocking, kein „RAM freigeben“. Das wird nicht simuliert.
- Die Erkennung „App begrenzt die Rate“ ist eine Messung der Display-Rate nach dem Anwenden, keine Messung
  der App-Framerate.

## Funktionsstufen

| Stufe | Voraussetzung |
|---|---|
| Standard | Berechtigung „Systemeinstellungen ändern“ |
| Advanced | einmalig per ADB: `adb shell pm grant com.tl.hz120 android.permission.WRITE_SECURE_SETTINGS` |
| Root | Root-Schalter in den Settings; wird nur genutzt, wenn die anderen Wege scheitern |

Shizuku ist in dieser Version **nicht** eingebaut (der ADB-Grant deckt den Advanced-Pfad ohne Fremdbibliothek ab).

## Berechtigungen (Settings-Tab)

1. **Systemeinstellungen ändern** – Pflicht für die Hz-Steuerung.
2. **Nutzungszugriff** – für automatische Profile pro App (Vordergrund-Erkennung).
3. **Über anderen Apps anzeigen** – für das Game-Overlay.
4. **Benachrichtigungen** – für die Dienst-Benachrichtigung (Android 13+).

Xiaomi/Redmi/POCO: zusätzlich Autostart erlauben und Akku-Sparmodus für die App auf „Keine Einschränkungen“
stellen, sonst beendet HyperOS/MIUI den Dienst. Samsung: App aus „Schlafende Apps“ nehmen.

## Bedienung

- **Home**: großer Ring = Ultra Refresh (höchste Rate, fest) an/aus, Statusübersicht.
- **Game Turbo**: erkannte Spiele (Android-Kategorie „Spiel“) und manuell hinzugefügte; Modus pro Spiel
  (Balanced / Performance / Ultra Refresh); schwebendes Overlay mit Live-Hz und Moduswechsel.
- **Applications**: Profil pro App, Ausnahmen (erzwingt Systemstandard).
- **Refresh Rate**: verfügbare Raten wählen (nicht vorhandene sind deaktiviert), Display-Modi des Geräts.
- **Settings**: Dienst, Autostart, Berechtigungen, ADB/Root, Protokoll.

Modi: *Balanced* = niedrigste bis höchste Rate (System entscheidet), *Performance* = feste Rate laut Profil,
*Ultra Refresh* = höchste Rate fest.

Schutzmechanismen: Maximal 6 Umschaltvorgänge in 12 s, danach 30 s Pause. Bei ausgeschaltetem Bildschirm
pausiert die Vordergrund-Erkennung. Beim Beenden des Dienstes (ohne aktiven globalen Modus) werden die
gesicherten Originalwerte wiederhergestellt; waren min/peak vorher nicht gesetzt, werden sie auf 0.0 (= ungesetzt) gestellt.

## APK bauen

**Variante A – Android Studio (empfohlen):** Ordner öffnen → Gradle-Sync → *Build → Build APK(s)*
(Debug) bzw. *Build → Generate Signed Bundle / APK* (Release). Android Studio Ladybug oder neuer, JDK 17.

**Variante B – GitHub Actions:** Projekt in ein GitHub-Repository pushen. Der Workflow
`.github/workflows/build.yml` baut `app-debug.apk` und `app-release.apk` und stellt sie als Artifact
„TL120Hz-APK“ bereit. Der Workflow erzeugt dabei einen Zufalls-Keystore; für Updates über bestehende
Installationen musst du einen eigenen Keystore verwenden (`keystore.properties` im Projektroot mit
`storeFile`, `storePassword`, `keyAlias`, `keyPassword`).

**Variante C – Kommandozeile:** `gradle assembleDebug assembleRelease` (Gradle 8.10+, JDK 17, Android SDK 35).
Ohne `keystore.properties` wird die Release-APK mit dem Debug-Schlüssel signiert und bleibt installierbar.

Installation: APK auf das Gerät kopieren und öffnen (Installation aus unbekannten Quellen erlauben).
Debug- und Release-APK haben dieselbe Paket-ID, aber verschiedene Signaturen – installiere nur eine davon.

## Projektstruktur

```
app/src/main/java/com/tl/hz120/
  data/      Modelle, lokale Speicherung
  system/    DisplayEngine, RefreshController, Vordergrund-Erkennung, App-Scanner, Berechtigungen
  service/   TurboService (Automatik), OverlayController, BootReceiver
  ui/        Compose-UI, ViewModel (MVVM)
```
