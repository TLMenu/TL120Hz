package com.ghostwriter.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val GwColors = darkColorScheme(
    primary = Color(0xFF01B4FD),
    onPrimary = Color(0xFF000000),
    secondary = Color(0xFF27FAFE),
    onSecondary = Color(0xFF000000),
    background = Color(0xFF000000),
    onBackground = Color(0xFFF3F4F7),
    surface = Color(0xFF0B111B),
    onSurface = Color(0xFFF3F4F7),
    surfaceVariant = Color(0xFF131C2B),
    onSurfaceVariant = Color(0xFFCDD0D5),
    outline = Color(0xFF17324F)
)

@Composable
fun GhostwriterTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = GwColors, content = content)
}
