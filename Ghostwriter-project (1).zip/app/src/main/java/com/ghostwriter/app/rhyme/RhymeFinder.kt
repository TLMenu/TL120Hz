package com.ghostwriter.app.rhyme

data class Rhyme(val word: String, val type: RhymeType)

/**
 * Findet Reime in einer lokalen Wortliste. Die Liste wird einmal indexiert,
 * danach ist jede Suche eine Hash-Abfrage.
 */
class RhymeFinder(words: Collection<String>) {

    private val byKey: Map<String, List<String>>

    init {
        byKey = words
            .map { it.trim().lowercase() }
            .filter { it.isNotEmpty() }
            .distinct()
            .groupBy { GermanRhyme.rhymeKey(it) }
            .filterKeys { it.isNotEmpty() }
    }

    val size: Int get() = byKey.values.sumOf { it.size }

    fun findRhymes(word: String, limit: Int = 60): List<Rhyme> {
        val own = word.trim().lowercase()
        val key = GermanRhyme.rhymeKey(own)
        if (key.isEmpty()) return emptyList()

        val exact = byKey[key].orEmpty()
            .filter { it != own }
            .map { Rhyme(it, RhymeType.REIN) }

        val nucleus = GermanRhyme.nucleus(key)
        val loose = if (exact.size >= limit) emptyList() else byKey.entries
            .asSequence()
            .filter { it.key != key && GermanRhyme.nucleus(it.key) == nucleus }
            .flatMap { it.value.asSequence() }
            .filter { it != own }
            .map { Rhyme(it, RhymeType.UNREIN) }
            .toList()

        return (exact + loose).take(limit)
    }
}
