package com.ghostwriter.app.rhyme

/**
 * Offline-Reimlogik für Deutsch (heuristisch, ohne Lexikon).
 *
 * Idee: Ab der letzten betonten Vokalgruppe zählt der Klang bis zum Wortende.
 * Unbetonte Endungen (-e, -en, -er, -em, -es) werden vorher abgeschnitten,
 * damit "Liebe" und "Triebe" gleich reimen.
 */
enum class RhymeType(val label: String) {
    REIN("Reiner Reim"),
    UNREIN("Unreiner Reim"),
    NONE("Kein Reim")
}

object GermanRhyme {
    private const val VOWELS = "aeiouy"
    private val ENDINGS = listOf("en", "em", "er", "es", "e")

    /** Kleinschreibung, Umlaute und Sonderzeichen vereinheitlichen. */
    fun normalize(raw: String): String {
        return raw.trim().lowercase()
            .replace("äu", "eu")
            .replace("ä", "a")
            .replace("ö", "o")
            .replace("ü", "u")
            .replace("ß", "ss")
            .replace("ai", "ei")
            .replace("ay", "ei")
            .replace("ey", "ei")
            .filter { it.isLetter() }
    }

    /** Reimschlüssel: Klang ab der letzten Vokalgruppe. Leer, wenn kein Vokal. */
    fun rhymeKey(raw: String): String {
        var w = normalize(raw)
        if (!w.any { it in VOWELS }) return ""
        for (end in ENDINGS) {
            if (w.endsWith(end)) {
                val stem = w.dropLast(end.length)
                if (stem.length >= 2 && stem.any { it in VOWELS }) {
                    w = stem
                    break
                }
            }
        }
        val start = vowelGroupStart(w)
        return w.substring(start)
    }

    /** Der Vokalkern des Schlüssels, z. B. "ieb" -> "ie". */
    fun nucleus(key: String): String = key.takeWhile { it in VOWELS }

    fun compare(a: String, b: String): RhymeType {
        val ka = rhymeKey(a)
        val kb = rhymeKey(b)
        if (ka.isEmpty() || kb.isEmpty()) return RhymeType.NONE
        if (ka == kb) return RhymeType.REIN
        val na = nucleus(ka)
        if (na.isNotEmpty() && na == nucleus(kb)) return RhymeType.UNREIN
        return RhymeType.NONE
    }

    private fun vowelGroupStart(w: String): Int {
        var i = w.length - 1
        while (i >= 0 && w[i] !in VOWELS) i--
        if (i < 0) return 0
        while (i > 0 && w[i - 1] in VOWELS) i--
        return i
    }
}

/** Ordnet Verszeilen ein Reimschema zu, z. B. "AABB" oder "ABAB". */
object RhymeScheme {
    fun lastWord(line: String): String =
        line.trim().split(Regex("\\s+")).lastOrNull()?.trimEnd { !it.isLetter() } ?: ""

    fun analyze(lines: List<String>): String {
        val letters = LinkedHashMap<String, Char>()
        val sb = StringBuilder()
        for (line in lines) {
            val key = GermanRhyme.rhymeKey(lastWord(line))
            if (key.isEmpty()) {
                sb.append('-')
                continue
            }
            val letter = letters.getOrPut(key) { 'A' + (letters.size % 26) }
            sb.append(letter)
        }
        return sb.toString()
    }
}
