package com.tl.hz120.system

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import com.tl.hz120.data.AppInfo
import com.tl.hz120.data.GameSource

/**
 * Listet Apps mit Launcher-Icon und erkennt Spiele in drei Stufen:
 *  1. Android-Kategorie "Game"
 *  2. Altes Spiel-Flag im Manifest
 *  3. Activity einer bekannten Spiel-Engine (Unity, Unreal, Godot) im Paket
 * Stufe 3 wird pro Paket gecacht (Schlüssel: lastUpdateTime), damit der Scan alle paar Minuten billig bleibt.
 */
class AppScanner(private val ctx: Context) {
    private data class EngineEntry(val stamp: Long, val source: GameSource)
    private val engineCache = HashMap<String, EngineEntry>()

    private val enginePrefixes = listOf(
        "com.unity3d.player." to GameSource.ENGINE,
        "com.epicgames.ue4." to GameSource.ENGINE,
        "org.godotengine." to GameSource.ENGINE
    )

    @Suppress("DEPRECATION")
    fun scan(): List<AppInfo> {
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, 0)
            .map { it.activityInfo.applicationInfo }
            .distinctBy { it.packageName }
            .filter { it.packageName != ctx.packageName }
            .map { ai ->
                val src = detect(ai)
                AppInfo(ai.packageName, pm.getApplicationLabel(ai).toString(), src != GameSource.NONE, src)
            }
            .sortedBy { it.label.lowercase() }
    }

    private fun detect(ai: ApplicationInfo): GameSource = when {
        ai.category == ApplicationInfo.CATEGORY_GAME -> GameSource.CATEGORY
        (ai.flags and ApplicationInfo.FLAG_IS_GAME) != 0 -> GameSource.FLAG
        else -> engineSource(ai.packageName)
    }

    private fun engineSource(pkg: String): GameSource {
        val pm = ctx.packageManager
        val info = try {
            pm.getPackageInfo(pkg, PackageManager.GET_ACTIVITIES)
        } catch (_: Exception) {
            return GameSource.NONE
        }
        val stamp = info.lastUpdateTime
        synchronized(engineCache) {
            engineCache[pkg]?.takeIf { it.stamp == stamp }?.let { return it.source }
        }
        val names = info.activities?.map { it.name.orEmpty() } ?: emptyList()
        val src = if (names.any { n -> enginePrefixes.any { n.startsWith(it.first) } }) GameSource.ENGINE else GameSource.NONE
        synchronized(engineCache) { engineCache[pkg] = EngineEntry(stamp, src) }
        return src
    }
}
