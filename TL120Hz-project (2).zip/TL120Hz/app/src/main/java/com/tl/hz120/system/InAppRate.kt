package com.tl.hz120.system

import android.app.Activity
import android.content.Context
import android.hardware.display.DisplayManager
import android.os.Build
import android.view.Display

/**
 * Setzt die Bildwiederholrate der App-Oberfläche auf die höchste Rate, die das Display bei der
 * aktuellen Auflösung bietet. 120-Hz-Geräte laufen also standardmäßig mit 120 Hz, 60/90-Hz-Geräte
 * mit ihrer eigenen Höchstrate. Es wird nur ein vorhandener Hardware-Modus gewählt.
 */
object InAppRate {

    /** Höchster Modus bei der aktuellen Auflösung, oder null, wenn das Display nicht lesbar ist. */
    fun bestMode(ctx: Context): Display.Mode? {
        val d = ctx.getSystemService(DisplayManager::class.java)?.getDisplay(Display.DEFAULT_DISPLAY) ?: return null
        val cur = d.mode
        return d.supportedModes
            .filter { it.physicalWidth == cur.physicalWidth && it.physicalHeight == cur.physicalHeight }
            .maxByOrNull { it.refreshRate }
    }

    /** Wendet den höchsten Modus auf das Fenster der Activity an. Mehrfach aufrufbar, idempotent. */
    @Suppress("DEPRECATION")
    fun apply(activity: Activity) {
        val best = bestMode(activity) ?: return
        val lp = activity.window.attributes
        if (lp.preferredDisplayModeId == best.modeId) return
        lp.preferredDisplayModeId = best.modeId
        if (Build.VERSION.SDK_INT >= 30) lp.preferredRefreshRate = best.refreshRate
        activity.window.attributes = lp
    }
}
