package com.tl.hz120.system

import android.content.Context
import com.tl.hz120.data.HardwareProfile
import org.json.JSONObject

/** Ein Eintrag der Kompatibilitätsdatenbank (assets/compat/devices.json). */
data class CompatEntry(
    val id: String,
    val title: String,
    val vendor: String,
    val modelPrefix: String?,
    val minSdk: Int?,
    val maxSdk: Int?,
    val verified: Boolean,
    val notes: List<String>
)

/**
 * Lokale Geräte- und Herstellerdatenbank. Keine Netzwerkanbindung: Die Datei wird mit der App
 * ausgeliefert und lässt sich ohne Codeänderung pflegen.
 */
class CompatDb(private val ctx: Context) {

    private val entries: List<CompatEntry> by lazy { load() }

    /** Passender Eintrag. Spezifischster Treffer gewinnt: Modell > Hersteller > allgemein. */
    fun match(h: HardwareProfile): CompatEntry {
        val model = h.model.lowercase()
        val best = entries
            .filter { e -> fits(e, h) }
            .maxByOrNull { e -> score(e, h, model) }
        return best ?: FALLBACK
    }

    private fun fits(e: CompatEntry, h: HardwareProfile): Boolean {
        if (e.vendor != "*" && e.vendor != h.vendorFamily) return false
        if (e.modelPrefix != null && !h.model.lowercase().startsWith(e.modelPrefix.lowercase())) return false
        if (e.minSdk != null && h.sdkInt < e.minSdk) return false
        if (e.maxSdk != null && h.sdkInt > e.maxSdk) return false
        return true
    }

    private fun score(e: CompatEntry, h: HardwareProfile, model: String): Int {
        var s = 0
        if (e.vendor != "*") s += 2
        if (e.modelPrefix != null) s += 4
        if (e.minSdk != null || e.maxSdk != null) s += 1
        return s
    }

    private fun load(): List<CompatEntry> = try {
        val text = ctx.assets.open("compat/devices.json").bufferedReader().use { it.readText() }
        val arr = JSONObject(text).getJSONArray("entries")
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            CompatEntry(
                id = o.getString("id"),
                title = o.optString("title", o.getString("id")),
                vendor = o.optString("vendor", "*"),
                modelPrefix = o.optString("modelPrefix").takeIf { it.isNotBlank() },
                minSdk = if (o.has("minSdk")) o.getInt("minSdk") else null,
                maxSdk = if (o.has("maxSdk")) o.getInt("maxSdk") else null,
                verified = o.optBoolean("verified", false),
                notes = o.optJSONArray("notes")?.let { n -> (0 until n.length()).map { n.getString(it) } } ?: emptyList()
            )
        }
    } catch (_: Exception) {
        emptyList()
    }

    companion object {
        /** Greift nur, wenn die Datei fehlt oder defekt ist. */
        val FALLBACK = CompatEntry(
            id = "fallback", title = "Kein Eintrag", vendor = "*", modelPrefix = null,
            minSdk = null, maxSdk = null, verified = false,
            notes = listOf("Für dieses Gerät gibt es keinen Eintrag. Das Ergebnis wird trotzdem gemessen.")
        )
    }
}
