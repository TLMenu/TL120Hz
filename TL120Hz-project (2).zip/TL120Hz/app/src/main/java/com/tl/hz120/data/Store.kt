package com.tl.hz120.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONArray
import org.json.JSONObject

/** Lokale Persistenz (SharedPreferences + JSON), keine Netzwerk- oder Cloud-Anbindung. */
class Store(ctx: Context) {
    private val sp = ctx.getSharedPreferences("tl120", Context.MODE_PRIVATE)
    private val _settings = MutableStateFlow(readSettings())
    val settings: StateFlow<TlSettings> = _settings

    @Synchronized
    fun update(f: (TlSettings) -> TlSettings) {
        val n = f(_settings.value)
        _settings.value = n
        sp.edit().putString("settings", encode(n)).apply()
    }

    /** Snapshot der Originalwerte der Systemeinstellungen (für sichere Wiederherstellung). */
    fun snapshot(): Map<String, String?>? {
        val raw = sp.getString("snap", null) ?: return null
        return try {
            val o = JSONObject(raw)
            o.keys().asSequence().associateWith { k -> if (o.isNull(k)) null else o.getString(k) }
        } catch (_: Exception) {
            null
        }
    }

    fun saveSnapshot(m: Map<String, String?>) {
        val o = JSONObject()
        m.forEach { (k, v) -> o.put(k, v ?: JSONObject.NULL) }
        sp.edit().putString("snap", o.toString()).apply()
    }

    fun clearSnapshot() {
        sp.edit().remove("snap").apply()
    }

    private fun encode(s: TlSettings): String = JSONObject().apply {
        put("gEnabled", s.global.enabled)
        put("gMode", s.global.mode.name)
        put("gHz", s.global.hz)
        put("profiles", JSONArray().also { a ->
            s.profiles.values.forEach { p ->
                a.put(JSONObject().put("pkg", p.pkg).put("mode", p.mode.name).put("hz", p.hz).put("on", p.enabled))
            }
        })
        put("black", JSONArray(s.blacklist.toList()))
        put("games", JSONArray(s.manualGames.toList()))
        put("hidden", JSONArray(s.hiddenGames.toList()))
        put("gameAuto", s.gameAuto)
        put("overlay", s.overlayEnabled)
        put("service", s.serviceEnabled)
        put("autoStart", s.autoStart)
        put("root", s.useRoot)
        put("interval", s.intervalMs)
    }.toString()

    private fun readSettings(): TlSettings {
        val raw = sp.getString("settings", null) ?: return TlSettings()
        return try {
            val j = JSONObject(raw)
            val profiles = HashMap<String, AppProfile>()
            val arr = j.optJSONArray("profiles")
            if (arr != null) {
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val p = AppProfile(o.getString("pkg"), modeOf(o.optString("mode")), o.optInt("hz"), o.optBoolean("on", true))
                    profiles[p.pkg] = p
                }
            }
            TlSettings(
                global = GlobalState(j.optBoolean("gEnabled"), modeOf(j.optString("gMode")), j.optInt("gHz")),
                profiles = profiles,
                blacklist = j.optJSONArray("black").strings(),
                manualGames = j.optJSONArray("games").strings(),
                hiddenGames = j.optJSONArray("hidden").strings(),
                gameAuto = j.optBoolean("gameAuto", true),
                overlayEnabled = j.optBoolean("overlay", true),
                serviceEnabled = j.optBoolean("service", false),
                autoStart = j.optBoolean("autoStart", true),
                useRoot = j.optBoolean("root", false),
                intervalMs = j.optLong("interval", 1500)
            )
        } catch (_: Exception) {
            TlSettings()
        }
    }

    private fun modeOf(s: String?) = PerfMode.values().firstOrNull { it.name == s } ?: PerfMode.ULTRA

    private fun JSONArray?.strings(): Set<String> =
        if (this == null) emptySet() else (0 until length()).map { getString(it) }.toSet()
}
