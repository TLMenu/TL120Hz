package com.tl.hz120.service

import android.content.Context
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import com.tl.hz120.data.PerfMode
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * Schwebendes Game-Turbo-Overlay (TYPE_APPLICATION_OVERLAY, Berechtigung "Über anderen Apps anzeigen").
 * Zeigt die aktuelle Rate und erlaubt den schnellen Wechsel des Modus für das laufende Spiel.
 */
class OverlayController(
    private val ctx: Context,
    private val onMode: (pkg: String, mode: PerfMode) -> Unit
) {
    private val wm = ctx.getSystemService(WindowManager::class.java)
    private val main = Handler(Looper.getMainLooper())
    private var box: LinearLayout? = null
    private var title: TextView? = null
    private var panel: LinearLayout? = null
    private var lp: WindowManager.LayoutParams? = null
    private var pkg: String? = null
    private var hz = 60f
    private val modeViews = HashMap<PerfMode, TextView>()

    private val accent = 0xFF1E8BFF.toInt()
    private val textCol = 0xFFEDEFF3.toInt()

    fun show(p: String, mode: PerfMode) {
        main.post {
            pkg = p
            if (box == null) build()
            highlight(mode)
        }
    }

    fun hide() {
        main.post {
            box?.let {
                try {
                    wm.removeView(it)
                } catch (_: Exception) {
                }
            }
            box = null
            panel = null
            title = null
            modeViews.clear()
        }
    }

    fun updateHz(h: Float) {
        hz = h
        main.post { title?.text = "${h.roundToInt()} Hz" }
    }

    private fun highlight(active: PerfMode) {
        modeViews.forEach { (m, v) -> v.setTextColor(if (m == active) accent else textCol) }
    }

    private fun build() {
        val d = ctx.resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()

        val container = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                setColor(0xE60D121A.toInt())
                cornerRadius = dp(18).toFloat()
                setStroke(dp(1), 0xFF262A33.toInt())
            }
            setPadding(dp(14), dp(8), dp(14), dp(8))
        }
        val t = TextView(ctx).apply {
            text = "${hz.roundToInt()} Hz"
            setTextColor(accent)
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(4), 0, dp(4))
        }
        val pnl = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
        }
        PerfMode.values().forEach { m ->
            val tv = TextView(ctx).apply {
                text = m.label
                textSize = 13f
                setTextColor(textCol)
                setPadding(0, dp(8), 0, dp(8))
                setOnClickListener {
                    pkg?.let { p -> onMode(p, m) }
                    highlight(m)
                }
            }
            modeViews[m] = tv
            pnl.addView(tv)
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(8)
            y = dp(160)
        }

        t.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0
            var sy = 0
            var tx = 0f
            var ty = 0f
            var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        sx = params.x; sy = params.y; tx = e.rawX; ty = e.rawY; moved = false
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (e.rawX - tx).toInt()
                        val dy = (e.rawY - ty).toInt()
                        if (abs(dx) > dp(4) || abs(dy) > dp(4)) moved = true
                        params.x = sx + dx
                        params.y = sy + dy
                        try {
                            wm.updateViewLayout(container, params)
                        } catch (_: Exception) {
                        }
                    }
                    MotionEvent.ACTION_UP -> if (!moved) {
                        pnl.visibility = if (pnl.visibility == View.GONE) View.VISIBLE else View.GONE
                        try {
                            wm.updateViewLayout(container, params)
                        } catch (_: Exception) {
                        }
                    }
                }
                return true
            }
        })

        container.addView(t)
        container.addView(pnl)
        try {
            wm.addView(container, params)
            box = container; title = t; panel = pnl; lp = params
        } catch (_: Exception) {
            // Overlay-Berechtigung fehlt oder wurde entzogen – still ignorieren.
        }
    }
}
