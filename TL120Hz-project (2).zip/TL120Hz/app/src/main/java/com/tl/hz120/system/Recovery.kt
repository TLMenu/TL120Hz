package com.tl.hz120.system

import android.content.Context
import com.tl.hz120.TlApp
import kotlinx.coroutines.runBlocking

/**
 * Wiederherstellung nach Abstürzen und Neustarts.
 *  - Absturz: Original-Systemwerte werden vor dem Beenden zurückgeschrieben.
 *  - Prozessstart: Hängengebliebene Änderungen werden zurückgenommen, wenn kein Dienst sie verwaltet.
 *  - Crash-Schleife: Treten mehrere Abstürze kurz hintereinander auf, werden Dienst und Autostart abgeschaltet.
 */
class Recovery(private val app: TlApp) {
    private val sp = app.getSharedPreferences("tl120_recovery", Context.MODE_PRIVATE)

    fun installCrashHandler() {
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            try {
                noteCrash()
                if (app.store.snapshot() != null) {
                    runBlocking { app.controller.restore() }
                }
            } catch (_: Throwable) {
                // Im Absturzpfad bleibt nur der Weg zum Standard-Handler.
            }
            previous?.uncaughtException(thread, error)
        }
    }

    /** Läuft einmal beim Prozessstart, noch vor Dienst und Oberfläche. */
    fun startupCheck() {
        if (recentCrashes().size >= LOOP_LIMIT) {
            app.store.update { it.copy(serviceEnabled = false, autoStart = false) }
            clearCrashes()
            app.log("Crash-Schleife erkannt: Dienst und Autostart deaktiviert")
        }
        val s = app.store.settings.value
        val managedNow = s.serviceEnabled && s.global.enabled
        if (app.store.snapshot() != null && !managedNow) {
            runBlocking { app.controller.restore() }
            app.log("Wiederhergestellt: Systemwerte nach unerwartetem Ende zurückgesetzt")
        }
    }

    private fun noteCrash() {
        val now = System.currentTimeMillis()
        val list = (recentCrashes() + now).joinToString(",")
        sp.edit().putString(KEY, list).apply()
    }

    /** Abstürze innerhalb des Zeitfensters. Ältere Einträge werden verworfen. */
    private fun recentCrashes(): List<Long> {
        val now = System.currentTimeMillis()
        val raw = sp.getString(KEY, null).orEmpty()
        return raw.split(",").mapNotNull { it.toLongOrNull() }.filter { now - it < WINDOW_MS }
    }

    private fun clearCrashes() {
        sp.edit().remove(KEY).apply()
    }

    private companion object {
        const val KEY = "crashes"
        const val WINDOW_MS = 10 * 60_000L
        const val LOOP_LIMIT = 3
    }
}
