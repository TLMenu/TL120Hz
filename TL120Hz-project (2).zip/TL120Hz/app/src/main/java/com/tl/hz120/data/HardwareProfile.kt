package com.tl.hz120.data

/** Momentaufnahme des Geräts, erzeugt vom SmartScanner. Nur Werte, die Android offiziell liefert. */
data class HardwareProfile(
    val manufacturer: String,
    val brand: String,
    val model: String,
    val device: String,
    val androidRelease: String,
    val sdkInt: Int,
    val securityPatch: String,
    val soc: String,
    val cpuCores: Int,
    val ramTotalMb: Long,
    val displayWidth: Int,
    val displayHeight: Int,
    val densityDpi: Int,
    val refreshRates: List<Int>,
    /** Normalisierter Herstellerschlüssel, z. B. "xiaomi", "samsung". Grundlage für die Kompatibilitätsdatenbank. */
    val vendorFamily: String,
    val scannedAt: Long
) {
    val maxHz: Int get() = refreshRates.maxOrNull() ?: 60
    val variableRefresh: Boolean get() = refreshRates.size > 1
}
