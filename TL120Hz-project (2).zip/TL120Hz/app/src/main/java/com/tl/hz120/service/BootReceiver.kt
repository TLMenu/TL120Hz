package com.tl.hz120.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.tl.hz120.TlApp

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val s = (context.applicationContext as TlApp).store.settings.value
        if (s.autoStart && s.serviceEnabled) TurboService.start(context)
    }
}
