package com.tl.hz120.system

import android.app.ActivityManager
import android.content.Context
import android.hardware.display.DisplayManager
import android.os.Build
import android.view.Display
import com.tl.hz120.data.HardwareProfile

/** Smart Scanner 2.0: liest das Hardwareprofil aus Build-, Speicher-, CPU- und Display-Informationen. */
class SmartScanner(private val ctx: Context, private val engine: DisplayEngine) {

    fun analyze(): HardwareProfile {
        val am = ctx.getSystemService(ActivityManager::class.java)
        val mem = ActivityManager.MemoryInfo().also { am?.getMemoryInfo(it) }
        val display = ctx.getSystemService(DisplayManager::class.java)?.getDisplay(Display.DEFAULT_DISPLAY)
        val mode = display?.mode
        val metrics = ctx.resources.displayMetrics

        val manufacturer = Build.MANUFACTURER.orEmpty().trim()
        val brand = Build.BRAND.orEmpty().trim()

        return HardwareProfile(
            manufacturer = manufacturer,
            brand = brand,
            model = Build.MODEL.orEmpty().trim(),
            device = Build.DEVICE.orEmpty().trim(),
            androidRelease = Build.VERSION.RELEASE.orEmpty(),
            sdkInt = Build.VERSION.SDK_INT,
            securityPatch = if (Build.VERSION.SDK_INT >= 23) Build.VERSION.SECURITY_PATCH.orEmpty() else "",
            soc = socName(),
            cpuCores = Runtime.getRuntime().availableProcessors(),
            ramTotalMb = mem.totalMem / (1024 * 1024),
            displayWidth = mode?.physicalWidth ?: metrics.widthPixels,
            displayHeight = mode?.physicalHeight ?: metrics.heightPixels,
            densityDpi = metrics.densityDpi,
            refreshRates = engine.availableRates(),
            vendorFamily = vendorFamily(manufacturer, brand),
            scannedAt = System.currentTimeMillis()
        )
    }

    /** SoC-Name: ab Android 12 aus Build.SOC_*, sonst Build.HARDWARE. "unknown" wird verworfen. */
    private fun socName(): String {
        val raw = if (Build.VERSION.SDK_INT >= 31) {
            listOf(Build.SOC_MANUFACTURER, Build.SOC_MODEL)
                .filter { !it.isNullOrBlank() && !it.equals("unknown", ignoreCase = true) }
                .joinToString(" ")
        } else ""
        return raw.ifBlank { Build.HARDWARE.orEmpty() }.trim()
    }

    private fun vendorFamily(manufacturer: String, brand: String): String {
        val m = manufacturer.lowercase()
        val b = brand.lowercase()
        return when {
            "xiaomi" in m || b in setOf("xiaomi", "redmi", "poco") -> "xiaomi"
            "samsung" in m || b == "samsung" -> "samsung"
            "oneplus" in m || b == "oneplus" -> "oneplus"
            "oppo" in m || b in setOf("oppo", "realme") -> "oppo"
            "google" in m -> "google"
            m.isBlank() -> "unbekannt"
            else -> m
        }
    }
}
