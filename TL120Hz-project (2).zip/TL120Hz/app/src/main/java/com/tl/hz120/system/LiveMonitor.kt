package com.tl.hz120.system

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.display.DisplayManager
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import android.view.Display
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn

enum class ThermalLevel(val label: String) {
    NORMAL("Normal"), WARM("Warm"), HOT("Heiß"), CRITICAL("Kritisch"), UNKNOWN("Unbekannt");

    /** Ab SEVERE drosselt Android typischerweise die Leistung. */
    val throttled get() = this == HOT || this == CRITICAL
}

data class LiveSnapshot(
    val hz: Float,
    val modeHz: Float,
    val resolution: String,
    val thermal: ThermalLevel,
    val batteryTempC: Float?,
    val batteryPct: Int,
    val charging: Boolean,
    val powerSave: Boolean,
    val availMemMb: Long,
    val lowMemory: Boolean,
    val sampledAt: Long
)

/** Live Monitor: liefert alle [intervalMs] eine Momentaufnahme. Nur echte Systemwerte, keine Schätzungen. */
class LiveMonitor(private val ctx: Context, private val engine: DisplayEngine) {

    fun flow(intervalMs: Long = 2000L): Flow<LiveSnapshot> = flow {
        while (true) {
            emit(sample())
            delay(intervalMs)
        }
    }.flowOn(Dispatchers.IO)

    private fun sample(): LiveSnapshot {
        val bat = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = bat?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = bat?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val pct = if (level >= 0 && scale > 0) level * 100 / scale else -1
        val status = bat?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
        val tempRaw = bat?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE) ?: Int.MIN_VALUE
        val tempC = if (tempRaw == Int.MIN_VALUE) null else tempRaw / 10f

        val pm = ctx.getSystemService(PowerManager::class.java)
        val thermal = if (Build.VERSION.SDK_INT >= 29) {
            thermalFromStatus(pm?.currentThermalStatus ?: -1)
        } else {
            thermalFromBattery(tempC)
        }

        val am = ctx.getSystemService(ActivityManager::class.java)
        val mem = ActivityManager.MemoryInfo().also { am?.getMemoryInfo(it) }

        val display = ctx.getSystemService(DisplayManager::class.java)?.getDisplay(Display.DEFAULT_DISPLAY)
        val mode = display?.mode
        val resolution = mode?.let { "${it.physicalWidth}×${it.physicalHeight}" } ?: "unbekannt"

        return LiveSnapshot(
            hz = engine.currentHz(),
            modeHz = engine.currentModeHz(),
            resolution = resolution,
            thermal = thermal,
            batteryTempC = tempC,
            batteryPct = pct,
            charging = charging,
            powerSave = pm?.isPowerSaveMode ?: false,
            availMemMb = mem.availMem / (1024 * 1024),
            lowMemory = mem.lowMemory,
            sampledAt = System.currentTimeMillis()
        )
    }

    /** Offizieller Android-Thermalstatus (API 29+). */
    private fun thermalFromStatus(s: Int): ThermalLevel = when (s) {
        PowerManager.THERMAL_STATUS_NONE, PowerManager.THERMAL_STATUS_LIGHT -> ThermalLevel.NORMAL
        PowerManager.THERMAL_STATUS_MODERATE -> ThermalLevel.WARM
        PowerManager.THERMAL_STATUS_SEVERE -> ThermalLevel.HOT
        PowerManager.THERMAL_STATUS_CRITICAL, PowerManager.THERMAL_STATUS_EMERGENCY,
        PowerManager.THERMAL_STATUS_SHUTDOWN -> ThermalLevel.CRITICAL
        else -> ThermalLevel.UNKNOWN
    }

    /** Grobe Näherung über die Akkutemperatur, nur wenn kein Thermalstatus verfügbar ist. */
    private fun thermalFromBattery(t: Float?): ThermalLevel = when {
        t == null -> ThermalLevel.UNKNOWN
        t < 40f -> ThermalLevel.NORMAL
        t < 45f -> ThermalLevel.WARM
        t < 50f -> ThermalLevel.HOT
        else -> ThermalLevel.CRITICAL
    }
}
