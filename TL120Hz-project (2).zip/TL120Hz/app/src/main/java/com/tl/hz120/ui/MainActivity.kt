package com.tl.hz120.ui

import android.os.Bundle
import com.tl.hz120.system.InAppRate
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        InAppRate.apply(this)
        setContent { TlTheme { TlRoot(vm) } }
    }

    override fun onResume() {
        super.onResume()
        InAppRate.apply(this)
        vm.refreshPerms()
    }
}

private data class Tab(val label: String, val icon: ImageVector)

@Composable
private fun TlRoot(vm: MainViewModel) {
    val tabs = remember {
        listOf(
            Tab("Home", Icons.Default.Home),
            Tab("Game Turbo", Icons.Default.PlayArrow),
            Tab("Apps", Icons.Default.Menu),
            Tab("Refresh", Icons.Default.Refresh),
            Tab("Settings", Icons.Default.Settings)
        )
    }
    var sel by rememberSaveable { mutableIntStateOf(0) }

    Scaffold(
        modifier = Modifier.background(Bg),
        containerColor = Bg,
        bottomBar = {
            NavigationBar(containerColor = Surface1) {
                tabs.forEachIndexed { i, t ->
                    NavigationBarItem(
                        selected = sel == i,
                        onClick = { sel = i },
                        icon = { Icon(t.icon, t.label) },
                        label = { Text(t.label) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Bg, selectedTextColor = Brand,
                            indicatorColor = Brand, unselectedIconColor = Muted, unselectedTextColor = Muted
                        )
                    )
                }
            }
        }
    ) { pad: PaddingValues ->
        Crossfade(sel, animationSpec = tween(220), label = "tab") { t ->
            when (t) {
                0 -> HomeScreen(vm, pad)
                1 -> GameTurboScreen(vm, pad)
                2 -> ApplicationsScreen(vm, pad)
                3 -> RefreshRateScreen(vm, pad)
                else -> SettingsScreen(vm, pad)
            }
        }
    }
}
