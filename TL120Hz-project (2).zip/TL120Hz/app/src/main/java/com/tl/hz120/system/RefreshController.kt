package com.tl.hz120.system

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.provider.Settings
import com.tl.hz120.data.Store
import com.tl.hz120.data.RateTarget
import com.tl.hz120.data.Verify
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * Setzt Refresh-Rate-Wünsche über die Systemeinstellungen, die der Display-Manager von Android
 * auswertet (min_refresh_rate / peak_refresh_rate). Ob ein Hersteller sie respektiert, wird nach
 * jedem Schreibvorgang am echten Display gemessen (Verify), nicht angenommen.
 *
 * Schreibwege (in dieser Reihenfolge):
 *  1. Settings.System          -> Sonderberechtigung "Systemeinstellungen ändern" (WRITE_SETTINGS)
 *  2. Settings.Secure          -> nur nach ADB-Grant von WRITE_SECURE_SETTINGS
 *  3. `su -c settings put ...` -> nur wenn der Nutzer Root-Modus aktiviert hat
 */
class RefreshController(
    private val ctx: Context,
    private val store: Store,
    private val engine: DisplayEngine
) {
    data class Result(val route: String, val verify: Verify, val observed: Float, val detail: String = "")

    private enum class Scope { SYSTEM, SECURE }
    private data class Key(val scope: Scope, val name: String) {
        val id get() = "${scope.name.lowercase()}:$name"
    }

    private val core = listOf(Key(Scope.SYSTEM, "min_refresh_rate"), Key(Scope.SYSTEM, "peak_refresh_rate"))

    // Herstellerspezifische Schlüssel werden NUR angefasst, wenn sie auf dem Gerät bereits existieren.
    private val vendorCandidates = listOf(Key(Scope.SYSTEM, "user_refresh_rate"), Key(Scope.SECURE, "miui_refresh_rate"))

    fun canWriteSystem(): Boolean = Settings.System.canWrite(ctx)
    fun canWriteSecure(): Boolean =
        ctx.checkSelfPermission(Manifest.permission.WRITE_SECURE_SETTINGS) == PackageManager.PERMISSION_GRANTED

    fun presentVendorKeys(): List<String> = vendorCandidates.filter { read(it) != null }.map { it.name }

    private fun vendorKeys() = vendorCandidates.filter { read(it) != null }

    private fun read(k: Key): String? = try {
        when (k.scope) {
            Scope.SYSTEM -> Settings.System.getString(ctx.contentResolver, k.name)
            Scope.SECURE -> Settings.Secure.getString(ctx.contentResolver, k.name)
        }
    } catch (_: Exception) {
        null
    }

    /** @return Name des genutzten Schreibwegs oder null. */
    private fun write(k: Key, v: String): String? {
        try {
            when (k.scope) {
                Scope.SYSTEM -> if (canWriteSystem() && Settings.System.putString(ctx.contentResolver, k.name, v))
                    return "Systemeinstellungen"
                Scope.SECURE -> if (canWriteSecure() && Settings.Secure.putString(ctx.contentResolver, k.name, v))
                    return "Secure Settings (ADB)"
            }
        } catch (_: SecurityException) {
        }
        if (store.settings.value.useRoot && root("settings put ${k.scope.name.lowercase()} ${k.name} $v")) return "Root"
        return null
    }

    private fun root(cmd: String): Boolean = try {
        val p = ProcessBuilder("su", "-c", cmd).redirectErrorStream(true).start()
        val done = p.waitFor(4, TimeUnit.SECONDS)
        if (!done) p.destroy()
        done && p.exitValue() == 0
    } catch (_: Exception) {
        false
    }

    fun rootAvailable(): Boolean = root("id")

    private fun ensureSnapshot() {
        if (store.snapshot() != null) return
        val snap = LinkedHashMap<String, String?>()
        (core + vendorKeys()).forEach { snap[it.id] = read(it) }
        store.saveSnapshot(snap)
    }

    private fun fmt(v: Float) = String.format(Locale.US, "%.1f", v)

    /** Schreibt Min/Peak und vorhandene Hersteller-Schlüssel. @return genutzte Schreibwege. */
    private fun writeAll(t: RateTarget): Set<String> {
        val routes = LinkedHashSet<String>()
        write(core[0], fmt(t.min))?.let { routes.add(it) }
        write(core[1], fmt(t.peak))?.let { routes.add(it) }
        vendorKeys().forEach { write(it, t.peak.roundToInt().toString())?.let { r -> routes.add(r) } }
        return routes
    }

    /**
     * Echte Verifikation: mehrere Messungen über bis zu 4 s. Bestätigt wird erst, wenn drei
     * Messungen in Folge passen. Bei fester Rate zählt zusätzlich der Modus des Displays, nicht nur
     * die gemeldete Rate, weil einige Systeme die Rate nur kurz anzeigen und dann zurückfallen.
     */
    private suspend fun verify(t: RateTarget): Pair<Verify, Float> {
        val deadline = System.currentTimeMillis() + 4000L
        var streak = 0
        var last = engine.currentHz()
        delay(800) // dem Display-Manager Zeit zum Umschalten geben
        while (System.currentTimeMillis() < deadline) {
            last = engine.currentHz()
            val ok = if (t.locked) {
                abs(last - t.peak) < 1.5f && abs(engine.currentModeHz() - t.peak) < 1.5f
            } else {
                last >= t.min - 1.5f
            }
            streak = if (ok) streak + 1 else 0
            if (streak >= 3) return Verify.CONFIRMED to last
            delay(250)
        }
        return Verify.NOT_CONFIRMED to last
    }

    suspend fun apply(t: RateTarget): Result = withContext(Dispatchers.IO) {
        ensureSnapshot()
        val routes = writeAll(t)
        if (routes.isEmpty()) return@withContext Result("–", Verify.NO_ROUTE, engine.currentHz(), "Kein Schreibweg verfügbar")

        var attempts = 1
        var (verdict, obs) = verify(t)
        if (verdict != Verify.CONFIRMED) {
            // Zweiter Versuch: manche Systeme verwerfen die erste Änderung, wenn sie zu schnell kommt.
            attempts = 2
            writeAll(t)
            val second = verify(t)
            verdict = second.first
            obs = second.second
        }
        val detail = "Ziel ${fmt(t.min)}–${fmt(t.peak)} Hz · gemessen ${obs.roundToInt()} Hz · Versuche $attempts"
        Result(routes.joinToString(" + "), verdict, obs, detail)
    }

    /** Stellt die vor dem ersten Eingriff gespeicherten Werte wieder her. */
    suspend fun restore() = withContext(Dispatchers.IO) {
        val snap = store.snapshot() ?: return@withContext
        snap.forEach { (id, v) ->
            val parts = id.split(":", limit = 2)
            if (parts.size != 2) return@forEach
            val scope = Scope.values().firstOrNull { it.name.lowercase() == parts[0] } ?: return@forEach
            val key = Key(scope, parts[1])
            // Existierte der Schlüssel vorher nicht, wird bei min/peak auf "0.0" (= ungesetzt) zurückgestellt.
            val value = v ?: if (key.name == "min_refresh_rate" || key.name == "peak_refresh_rate") "0.0" else null
            if (value != null) write(key, value)
        }
        store.clearSnapshot()
    }
}
