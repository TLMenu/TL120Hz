plugins {
    id("com.android.application") version "9.5.0" apply false
    // AGP 9 bringt Kotlin selbst mit: kein org.jetbrains.kotlin.android mehr nötig.
    id("org.jetbrains.kotlin.plugin.compose") version "2.2.0" apply false
}
